<?php
/**
 * AutoCad ConsumeR — Manual Rocket Send Money Gateway
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

class CAD_Gateway_Rocket extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'cad_rocket';
        $this->icon               = CAD_CORE_URI . 'assets/images/rocket-logo.svg';
        $this->has_fields         = true;
        $this->method_title       = __('Rocket Send Money (DBBL Manual)', 'autocad-consumer-core');
        $this->method_description = __('Allows customers to pay via manual Dutch-Bangla Rocket Send Money.', 'autocad-consumer-core');

        $this->init_form_fields();
        $this->init_settings();

        $this->title        = $this->get_option('title', 'Rocket (DBBL)');
        $this->description  = $this->get_option('description', 'Send Money to our Rocket wallet and submit your 12-digit number and TrxID.');
        $this->account_no   = $this->get_option('account_no', '017123456789');
        $this->account_type = $this->get_option('account_type', 'Personal');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'autocad-consumer-core'),
                'type'    => 'checkbox',
                'label'   => __('Enable Rocket Payment', 'autocad-consumer-core'),
                'default' => 'yes',
            ),
            'title' => array(
                'title'   => __('Method Title', 'autocad-consumer-core'),
                'type'    => 'text',
                'default' => __('Rocket Send Money', 'autocad-consumer-core'),
            ),
            'account_no' => array(
                'title'       => __('Rocket 12-digit Number', 'autocad-consumer-core'),
                'type'        => 'text',
                'description' => __('Include the 12th check digit if required.', 'autocad-consumer-core'),
                'default'     => '017123456789',
            ),
            'account_type' => array(
                'title'   => __('Account Type', 'autocad-consumer-core'),
                'type'    => 'select',
                'options' => array(
                    'Personal' => __('Personal', 'autocad-consumer-core'),
                    'Merchant' => __('Merchant', 'autocad-consumer-core'),
                ),
                'default' => 'Personal',
            ),
            'description' => array(
                'title'   => __('Instructions', 'autocad-consumer-core'),
                'type'    => 'textarea',
                'default' => __("1. Dial *322# or open Rocket App\n2. Choose 'Send Money'\n3. Enter our 12-digit Rocket account number\n4. Enter exact amount and submit your TrxID below.", 'autocad-consumer-core'),
            ),
        );
    }

    public function payment_fields() {
        ?>
        <div class="cad-gateway-box">
            <div class="cad-gateway-instructions">
                <?php echo nl2br(esc_html($this->description)); ?>
            </div>

            <div style="margin-bottom:12px;">
                <span style="font-size:0.8125rem; color:#64748B; font-weight:600; text-transform:uppercase;">
                    <?php printf(esc_html__('Our %s Rocket Number:', 'autocad-consumer-core'), esc_html($this->account_type)); ?>
                </span><br>
                <div class="cad-gateway-number-badge" style="color:#8C3494;">
                    <?php echo esc_html($this->account_no); ?>
                </div>
            </div>

            <div class="cad-gateway-input-group">
                <label for="cad_rocket_sender_number"><?php esc_html_e('Your Rocket Number (12 digits) *', 'autocad-consumer-core'); ?></label>
                <input type="text" id="cad_rocket_sender_number" name="cad_rocket_sender_number" placeholder="e.g. 017XXXXXXXXX" required />
            </div>

            <div class="cad-gateway-input-group">
                <label for="cad_rocket_trxid"><?php esc_html_e('Rocket Transaction ID (TrxID) *', 'autocad-consumer-core'); ?></label>
                <input type="text" id="cad_rocket_trxid" name="cad_rocket_trxid" placeholder="e.g. RCK1298492" required style="text-transform:uppercase;" />
            </div>

            <div class="cad-payment-pending-alert">
                <?php esc_html_e('Order will remain pending manual verification by our accounting staff.', 'autocad-consumer-core'); ?>
            </div>
        </div>
        <?php
    }

    public function validate_fields() {
        $sender = isset($_POST['cad_rocket_sender_number']) ? sanitize_text_field(wp_unslash($_POST['cad_rocket_sender_number'])) : '';
        $trxid  = isset($_POST['cad_rocket_trxid']) ? sanitize_text_field(wp_unslash($_POST['cad_rocket_trxid'])) : '';

        if (empty($sender) || strlen($sender) < 11) {
            wc_add_notice(__('Please enter your valid Rocket account number.', 'autocad-consumer-core'), 'error');
            return false;
        }

        if (empty($trxid)) {
            wc_add_notice(__('Please enter the Rocket Transaction ID.', 'autocad-consumer-core'), 'error');
            return false;
        }

        return true;
    }

    public function process_payment($order_id) {
        $order  = wc_get_order($order_id);
        $sender = isset($_POST['cad_rocket_sender_number']) ? sanitize_text_field(wp_unslash($_POST['cad_rocket_sender_number'])) : '';
        $trxid  = isset($_POST['cad_rocket_trxid']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['cad_rocket_trxid']))) : '';

        $order->update_meta_data('_cad_payment_provider', 'Rocket');
        $order->update_meta_data('_cad_payment_recipient', $this->account_no);
        $order->update_meta_data('_cad_payment_sender_number', $sender);
        $order->update_meta_data('_cad_payment_trxid', $trxid);
        $order->update_meta_data('_cad_payment_verified', 'no');

        $order->update_status('wc-pending-verify', sprintf(
            __('Manual Rocket payment submitted. Sender: %s | TrxID: %s. Awaiting admin verification.', 'autocad-consumer-core'),
            $sender,
            $trxid
        ));

        wc_reduce_stock_levels($order_id);
        WC()->cart->empty_cart();

        return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url($order),
        );
    }

    public function thankyou_page($order_id) {
        $order = wc_get_order($order_id);
        ?>
        <div style="background:#F8FAFC; border:1px solid #E2E8F0; padding:20px; border-radius:8px; margin:24px 0;">
            <h3 style="color:#0B1220; margin-top:0;"><?php esc_html_e('Rocket Payment Submitted', 'autocad-consumer-core'); ?></h3>
            <p>
                <strong><?php esc_html_e('Recipient Rocket Number:', 'autocad-consumer-core'); ?></strong> <?php echo esc_html($this->account_no); ?><br>
                <strong><?php esc_html_e('Your Rocket Sender:', 'autocad-consumer-core'); ?></strong> <?php echo esc_html($order->get_meta('_cad_payment_sender_number')); ?><br>
                <strong><?php esc_html_e('TrxID:', 'autocad-consumer-core'); ?></strong> <span style="font-family:monospace; font-weight:bold; color:#8C3494;"><?php echo esc_html($order->get_meta('_cad_payment_trxid')); ?></span>
            </p>
        </div>
        <?php
    }
}
