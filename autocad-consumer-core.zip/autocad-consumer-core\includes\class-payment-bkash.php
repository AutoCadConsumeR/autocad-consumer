<?php
/**
 * AutoCad ConsumeR — Manual bKash Send Money Gateway
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

class CAD_Gateway_bKash extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'cad_bkash';
        $this->icon               = CAD_CORE_URI . 'assets/images/bkash-logo.svg';
        $this->has_fields         = true;
        $this->method_title       = __('bKash Send Money (Manual)', 'autocad-consumer-core');
        $this->method_description = __('Allows customers to pay via manual bKash Send Money with admin-verified transaction references.', 'autocad-consumer-core');

        $this->init_form_fields();
        $this->init_settings();

        $this->title        = $this->get_option('title', 'bKash Send Money');
        $this->description  = $this->get_option('description', 'Send Money to our official bKash number and enter your Sender Number & TrxID below.');
        $this->account_no   = $this->get_option('account_no', '01878205459');
        $this->account_type = $this->get_option('account_type', 'Personal');
        $this->qr_code      = $this->get_option('qr_code', '');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        add_action('woocommerce_email_before_order_table', array($this, 'email_instructions'), 10, 3);
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'autocad-consumer-core'),
                'type'    => 'checkbox',
                'label'   => __('Enable bKash Send Money', 'autocad-consumer-core'),
                'default' => 'yes',
            ),
            'title' => array(
                'title'       => __('Method Title', 'autocad-consumer-core'),
                'type'        => 'text',
                'description' => __('Payment method title that the customer sees at checkout.', 'autocad-consumer-core'),
                'default'     => __('bKash Send Money', 'autocad-consumer-core'),
                'desc_tip'    => true,
            ),
            'account_no' => array(
                'title'       => __('bKash Recipient Number', 'autocad-consumer-core'),
                'type'        => 'text',
                'description' => __('The official bKash mobile number where customers will send money.', 'autocad-consumer-core'),
                'default'     => '01878205459',
                'desc_tip'    => true,
            ),
            'account_type' => array(
                'title'       => __('Account Type', 'autocad-consumer-core'),
                'type'        => 'select',
                'options'     => array(
                    'Personal' => __('Personal (Send Money)', 'autocad-consumer-core'),
                    'Merchant' => __('Merchant (Payment)', 'autocad-consumer-core'),
                    'Agent'    => __('Agent (Cash In)', 'autocad-consumer-core'),
                ),
                'default'     => 'Personal',
            ),
            'description' => array(
                'title'       => __('Checkout Instructions', 'autocad-consumer-core'),
                'type'        => 'textarea',
                'description' => __('Step-by-step instructions displayed to the customer at checkout.', 'autocad-consumer-core'),
                'default'     => __("1. Open bKash App or dial *247#\n2. Select 'Send Money' to our number\n3. Enter the exact order amount in BDT\n4. Use your Order ID or Name as reference\n5. Enter your Sender Number and Transaction ID (TrxID) below.", 'autocad-consumer-core'),
            ),
            'qr_code' => array(
                'title'       => __('Optional QR Code Image URL', 'autocad-consumer-core'),
                'type'        => 'text',
                'description' => __('Link to your bKash QR code graphic.', 'autocad-consumer-core'),
                'default'     => '',
            ),
        );
    }

    public function payment_fields() {
        ?>
        <div class="cad-gateway-box">
            <div class="cad-gateway-instructions">
                <?php echo nl2br(esc_html($this->description)); ?>
            </div>

            <div style="margin-bottom:12px;">
                <span style="font-size:0.8125rem; color:#64748B; font-weight:600; text-transform:uppercase;">
                    <?php printf(esc_html__('Our %s bKash Number:', 'autocad-consumer-core'), esc_html($this->account_type)); ?>
                </span><br>
                <div class="cad-gateway-number-badge">
                    <?php echo esc_html($this->account_no); ?>
                </div>
            </div>

            <?php if (!empty($this->qr_code)) : ?>
                <div style="margin-bottom:14px;">
                    <img src="<?php echo esc_url($this->qr_code); ?>" alt="bKash QR" style="max-width:140px; border-radius:6px; border:1px solid #E2E8F0;" />
                </div>
            <?php endif; ?>

            <div class="cad-gateway-input-group">
                <label for="cad_bkash_sender_number"><?php esc_html_e('Your bKash Sender Number *', 'autocad-consumer-core'); ?></label>
                <input type="text" id="cad_bkash_sender_number" name="cad_bkash_sender_number" placeholder="e.g. 017XXXXXXXX" required />
            </div>

            <div class="cad-gateway-input-group">
                <label for="cad_bkash_trxid"><?php esc_html_e('bKash Transaction ID (TrxID) *', 'autocad-consumer-core'); ?></label>
                <input type="text" id="cad_bkash_trxid" name="cad_bkash_trxid" placeholder="e.g. 9J583KFA1" required style="text-transform:uppercase;" />
            </div>

            <div class="cad-payment-pending-alert">
                <strong><?php esc_html_e('Important Verification Notice:', 'autocad-consumer-core'); ?></strong>
                <?php esc_html_e('Submitting a Transaction ID does not instantly confirm payment. Our admin team will verify the payment before delivering digital CAD files or beginning drafting services.', 'autocad-consumer-core'); ?>
            </div>
        </div>
        <?php
    }

    public function validate_fields() {
        $sender = isset($_POST['cad_bkash_sender_number']) ? sanitize_text_field(wp_unslash($_POST['cad_bkash_sender_number'])) : '';
        $trxid  = isset($_POST['cad_bkash_trxid']) ? sanitize_text_field(wp_unslash($_POST['cad_bkash_trxid'])) : '';

        if (empty($sender)) {
            wc_add_notice(__('Please enter your bKash sender mobile number.', 'autocad-consumer-core'), 'error');
            return false;
        }

        // Validate Bangladeshi phone number pattern
        if (!preg_match('/^(01)[3-9]{1}[0-9]{8}$/', $sender)) {
            wc_add_notice(__('Please provide a valid 11-digit Bangladeshi bKash number (01XXXXXXXXX).', 'autocad-consumer-core'), 'error');
            return false;
        }

        if (empty($trxid) || strlen($trxid) < 6) {
            wc_add_notice(__('Please enter a valid bKash Transaction ID (TrxID).', 'autocad-consumer-core'), 'error');
            return false;
        }

        return true;
    }

    public function process_payment($order_id) {
        $order  = wc_get_order($order_id);
        $sender = isset($_POST['cad_bkash_sender_number']) ? sanitize_text_field(wp_unslash($_POST['cad_bkash_sender_number'])) : '';
        $trxid  = isset($_POST['cad_bkash_trxid']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['cad_bkash_trxid']))) : '';

        // Save metadata
        $order->update_meta_data('_cad_payment_provider', 'bKash');
        $order->update_meta_data('_cad_payment_recipient', $this->account_no);
        $order->update_meta_data('_cad_payment_sender_number', $sender);
        $order->update_meta_data('_cad_payment_trxid', $trxid);
        $order->update_meta_data('_cad_payment_verified', 'no');

        // Set status to pending verification
        $order->update_status('wc-pending-verify', sprintf(
            __('Manual bKash payment submitted. Sender: %s | TrxID: %s. Awaiting admin verification.', 'autocad-consumer-core'),
            $sender,
            $trxid
        ));

        // Reduce stock levels safely
        wc_reduce_stock_levels($order_id);

        // Clear cart
        WC()->cart->empty_cart();

        return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url($order),
        );
    }

    public function thankyou_page($order_id) {
        $order  = wc_get_order($order_id);
        $sender = $order->get_meta('_cad_payment_sender_number');
        $trxid  = $order->get_meta('_cad_payment_trxid');
        ?>
        <div style="background:#F8FAFC; border:1px solid #E2E8F0; padding:20px; border-radius:8px; margin:24px 0;">
            <h3 style="color:#0B1220; margin-top:0;"><?php esc_html_e('bKash Payment Details Submitted', 'autocad-consumer-core'); ?></h3>
            <p>
                <strong><?php esc_html_e('Recipient bKash Number:', 'autocad-consumer-core'); ?></strong> <?php echo esc_html($this->account_no); ?><br>
                <strong><?php esc_html_e('Your Sender Mobile:', 'autocad-consumer-core'); ?></strong> <?php echo esc_html($sender); ?><br>
                <strong><?php esc_html_e('Transaction ID (TrxID):', 'autocad-consumer-core'); ?></strong> <span style="font-family:monospace; font-weight:bold; color:#E50914;"><?php echo esc_html($trxid); ?></span>
            </p>
            <div style="background:#EFF6FF; border-left:4px solid #1769AA; padding:12px; font-size:0.875rem; color:#1E3A8A;">
                <?php esc_html_e('Our verification engineer is reviewing your transaction. Once verified, download permissions for digital files will unlock automatically under your account.', 'autocad-consumer-core'); ?>
            </div>
        </div>
        <?php
    }

    public function email_instructions($order, $sent_to_admin, $plain_text = false) {
        if ($order->get_payment_method() !== $this->id) return;
        $trxid  = $order->get_meta('_cad_payment_trxid');
        $sender = $order->get_meta('_cad_payment_sender_number');

        echo "\n========================================\n";
        echo "bKash Payment Reference:\n";
        echo "Recipient Number: " . esc_html($this->account_no) . "\n";
        echo "Sender Number: " . esc_html($sender) . "\n";
        echo "Transaction ID (TrxID): " . esc_html($trxid) . "\n";
        echo "Status: Awaiting Admin Verification\n";
        echo "========================================\n\n";
    }
}
