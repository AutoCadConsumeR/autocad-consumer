<?php
/**
 * AutoCad ConsumeR — Anti-Fake-Order Protection & Fraud Detection Engine
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

class CAD_Fake_Order_Protection {

    public function __construct() {
        // Checkout Validation
        add_action('woocommerce_checkout_process', array($this, 'validate_checkout_fields'));

        // Order Creation Inspection
        add_action('woocommerce_checkout_order_processed', array($this, 'inspect_and_flag_order'), 10, 3);

        // Admin Order List Column Badge
        add_filter('manage_edit-shop_order_columns', array($this, 'add_order_fraud_column'));
        add_action('manage_shop_order_posts_custom_column', array($this, 'render_order_fraud_column'), 10, 2);
    }

    /**
     * Server-side Validation of Bangladeshi Phone Number & Rate Limiting
     */
    public function validate_checkout_fields() {
        // 1. Phone number validation
        $billing_phone = isset($_POST['billing_phone']) ? sanitize_text_field(wp_unslash($_POST['billing_phone'])) : '';
        $billing_phone = preg_replace('/[^0-9]/', '', $billing_phone);

        // Check for 880 prefix and strip
        if (substr($billing_phone, 0, 3) === '880') {
            $billing_phone = substr($billing_phone, 2);
        }

        if (!empty($billing_phone) && !preg_match('/^(01)[3-9]{1}[0-9]{8}$/', $billing_phone)) {
            wc_add_notice(__('Please enter a valid 11-digit Bangladeshi mobile number (e.g. 01712345678).', 'autocad-consumer-core'), 'error');
        }

        // 2. Checkout Rate Limiting (Bot protection)
        $client_ip = $this->get_client_ip();
        $rate_key  = 'cad_checkout_rate_' . md5($client_ip);
        $attempts  = (int)get_transient($rate_key);

        if ($attempts >= 5) {
            wc_add_notice(__('Too many order attempts from your network. Please wait a few minutes before trying again or contact support.', 'autocad-consumer-core'), 'error');
            return;
        }

        // Increment attempt count with 15-minute expiry
        set_transient($rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
    }

    /**
     * Inspect order upon placement, check for duplicate phone numbers and IP patterns
     */
    public function inspect_and_flag_order($order_id, $posted_data, $order) {
        $phone = $order->get_billing_phone();
        $phone_clean = preg_replace('/[^0-9]/', '', $phone);
        $client_ip   = $this->get_client_ip();
        $is_flagged  = false;
        $flag_reasons = array();

        // 1. Duplicate Phone Check in Last 24 Hours
        if (!empty($phone_clean)) {
            $recent_orders = wc_get_orders(array(
                'limit'        => 5,
                'billing_phone'=> $phone,
                'date_after'   => gmdate('Y-m-d H:i:s', strtotime('-24 hours')),
                'exclude'      => array($order_id),
            ));

            if (!empty($recent_orders)) {
                $is_flagged = true;
                $count = count($recent_orders);
                $flag_reasons[] = sprintf(__('%d other order(s) placed with this phone number within the last 24 hours.', 'autocad-consumer-core'), $count);
            }
        }

        // 2. High Value COD Check
        if ($order->get_payment_method() === 'cad_cod' && $order->get_total() > 5000) {
            $is_flagged = true;
            $flag_reasons[] = __('High-value Cash on Delivery order (> ৳5,000). Requires verbal phone confirmation before dispatch.', 'autocad-consumer-core');
        }

        // Save Flag and Add Private Order Notes
        if ($is_flagged) {
            $order->update_meta_data('_cad_fraud_flagged', 'yes');
            $order->update_meta_data('_cad_flag_reasons', implode(' | ', $flag_reasons));
            $order->add_order_note('⚠️ [SECURITY REVIEW FLAGGED]: ' . implode(' | ', $flag_reasons));
            $order->save();
        } else {
            $order->update_meta_data('_cad_fraud_flagged', 'no');
            $order->save();
        }

        // Record Order IP
        $order->update_meta_data('_cad_customer_ip', $client_ip);
        $order->save();
    }

    /**
     * Add Security / Fraud Column to Order List
     */
    public function add_order_fraud_column($columns) {
        $new_columns = array();
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;
            if ('order_status' === $key) {
                $new_columns['cad_fraud_status'] = __('Security Check', 'autocad-consumer-core');
            }
        }
        return $new_columns;
    }

    public function render_order_fraud_column($column, $post_id) {
        if ('cad_fraud_status' === $column) {
            $order = wc_get_order($post_id);
            if (!$order) return;

            $is_flagged = $order->get_meta('_cad_fraud_flagged');
            if ($is_flagged === 'yes') {
                $reason = $order->get_meta('_cad_flag_reasons');
                echo '<span class="cad-badge-flagged" title="' . esc_attr($reason) . '" style="background:#FEE2E2; color:#991B1B; padding:3px 8px; border-radius:4px; font-size:0.75rem; font-weight:bold;">⚠️ Review Needed</span>';
            } else {
                echo '<span style="color:#059669; font-size:0.75rem; font-weight:600;">✓ Clean</span>';
            }
        }
    }

    private function get_client_ip() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return sanitize_text_field(wp_unslash($_SERVER['HTTP_CLIENT_IP']));
        }
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip_list = explode(',', sanitize_text_field(wp_unslash($_SERVER['HTTP_X_FORWARDED_FOR'])));
            return trim($ip_list[0]);
        }
        return isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '127.0.0.1';
    }
}

new CAD_Fake_Order_Protection();
