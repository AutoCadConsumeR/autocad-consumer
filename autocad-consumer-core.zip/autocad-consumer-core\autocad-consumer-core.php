<?php
/**
 * Plugin Name: AutoCad ConsumeR Core
 * Plugin URI: https://autocadconsumer.com
 * Description: Official companion plugin for the AutoCad ConsumeR store. Powers manual bKash, Nagad, Rocket & COD payment gateways, anti-fake-order protection, quote requests, administrative dashboard widgets, sample CAD product seeder, and variation enhancements.
 * Version: 1.0.0
 * Author: AutoCad ConsumeR Team
 * Author URI: https://autocadconsumer.com
 * Text Domain: autocad-consumer-core
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CAD_CORE_VERSION', '1.0.0');
define('CAD_CORE_DIR', plugin_dir_path(__FILE__));
define('CAD_CORE_URI', plugin_dir_url(__FILE__));

/**
 * Main Plugin Initialization Class
 */
class AutoCad_ConsumeR_Core {

    private static $instance = null;

    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        $this->includes();
        $this->init_hooks();
    }

    private function includes() {
        require_once CAD_CORE_DIR . 'includes/class-settings.php';
        require_once CAD_CORE_DIR . 'includes/class-fake-order-protection.php';
        require_once CAD_CORE_DIR . 'includes/class-order-management.php';
        require_once CAD_CORE_DIR . 'includes/class-service-quote.php';
        require_once CAD_CORE_DIR . 'includes/class-demo-importer.php';

        // Payment Gateways
        require_once CAD_CORE_DIR . 'includes/class-payment-bkash.php';
        require_once CAD_CORE_DIR . 'includes/class-payment-nagad.php';
        require_once CAD_CORE_DIR . 'includes/class-payment-rocket.php';
        require_once CAD_CORE_DIR . 'includes/class-payment-cod.php';
    }

    private function init_hooks() {
        // Register custom order status: Pending Verification
        add_action('init', array($this, 'register_custom_order_status'));
        add_filter('wc_order_statuses', array($this, 'add_custom_order_status_to_list'));

        // Register custom payment gateways into WooCommerce
        add_filter('woocommerce_payment_gateways', array($this, 'register_payment_gateways'));

        // Admin CSS & JS
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

        // Enqueue checkout script for gateway previews
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
    }

    /**
     * Register Custom Order Status: Pending Payment Verification
     */
    public function register_custom_order_status() {
        register_post_status('wc-pending-verify', array(
            'label'                     => _x('Pending Payment Verification', 'Order status', 'autocad-consumer-core'),
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop('Pending Verification (%s)', 'Pending Verification (%s)', 'autocad-consumer-core')
        ));
    }

    public function add_custom_order_status_to_list($order_statuses) {
        $new_statuses = array();
        foreach ($order_statuses as $key => $status) {
            $new_statuses[$key] = $status;
            if ('wc-on-hold' === $key) {
                $new_statuses['wc-pending-verify'] = _x('Pending Payment Verification', 'Order status', 'autocad-consumer-core');
            }
        }
        return $new_statuses;
    }

    /**
     * Register bKash, Nagad, Rocket, and enhanced COD into WooCommerce
     */
    public function register_payment_gateways($gateways) {
        $gateways[] = 'CAD_Gateway_bKash';
        $gateways[] = 'CAD_Gateway_Nagad';
        $gateways[] = 'CAD_Gateway_Rocket';
        $gateways[] = 'CAD_Gateway_COD';
        return $gateways;
    }

    public function enqueue_admin_assets($hook) {
        wp_enqueue_style('cad-core-admin-css', CAD_CORE_URI . 'assets/css/admin.css', array(), CAD_CORE_VERSION);
        wp_enqueue_script('cad-core-admin-js', CAD_CORE_URI . 'assets/js/admin.js', array('jquery'), CAD_CORE_VERSION, true);

        wp_localize_script('cad-core-admin-js', 'cadAdminData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('cad_admin_nonce'),
        ));
    }

    public function enqueue_frontend_assets() {
        if (is_checkout()) {
            wp_enqueue_style('cad-core-gateway-css', CAD_CORE_URI . 'assets/css/gateway.css', array(), CAD_CORE_VERSION);
            wp_enqueue_script('cad-core-gateway-js', CAD_CORE_URI . 'assets/js/gateway-checkout.js', array('jquery'), CAD_CORE_VERSION, true);
        }
    }
}

// Initialize Plugin
function autocad_consumer_core_init() {
    return AutoCad_ConsumeR_Core::instance();
}
add_action('plugins_loaded', 'autocad_consumer_core_init');
