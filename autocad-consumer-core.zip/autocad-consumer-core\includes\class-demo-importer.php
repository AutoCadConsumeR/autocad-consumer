<?php
/**
 * AutoCad ConsumeR — Sample CAD Products & Categories Seeder
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

class CAD_Demo_Importer {

    public function __construct() {
        add_action('wp_ajax_cad_run_sample_seeder', array($this, 'ajax_run_seeder'));
    }

    public function ajax_run_seeder() {
        check_ajax_referer('cad_admin_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'Unauthorized user.'));
        }

        if (!class_exists('WooCommerce')) {
            wp_send_json_error(array('message' => 'WooCommerce must be activated first.'));
        }

        // 1. Create Product Categories
        $categories = array(
            'cad-blocks'    => array('name' => 'CAD Blocks & Symbols', 'desc' => '1,500+ Furniture, electrical, plumbing, sanitary, and mechanical 2D blocks.'),
            'templates'     => array('name' => 'DWG/DXF Templates', 'desc' => 'Standardized drawing sheets, title blocks (A0 to A4), and CTB plot styles.'),
            'architectural' => array('name' => 'Architectural Drafting', 'desc' => 'Full residential & commercial drawings: floor plans, elevations, sections.'),
            'structural'    => array('name' => 'Structural Drawing Resources', 'desc' => 'RC column/beam rebar details, foundation layouts, and steel connections.'),
            'boq-tools'     => array('name' => 'BOQ & Estimation Tools', 'desc' => 'Dynamic Excel spreadsheets with automated rate analysis for Bangladesh.'),
            'services'      => array('name' => 'Custom CAD Design Services', 'desc' => 'Turnkey 2D drafting, PDF-to-CAD conversion, redline cleanups, and plotting.'),
        );

        $cat_ids = array();
        foreach ($categories as $slug => $data) {
            $term = term_exists($slug, 'product_cat');
            if (!$term) {
                $inserted = wp_insert_term($data['name'], 'product_cat', array(
                    'slug'        => $slug,
                    'description' => $data['desc'],
                ));
                if (!is_wp_error($inserted)) {
                    $cat_ids[$slug] = $inserted['term_id'];
                }
            } else {
                $cat_ids[$slug] = is_array($term) ? $term['term_id'] : $term;
            }
        }

        // 2. Create Global Attributes (Format & Licence)
        $this->create_global_attributes();

        // 3. Create Sample CAD Products
        // Product 1: Simple Downloadable Template
        $this->create_simple_downloadable_product(
            'Standard DWG/DXF Title Block & Sheet Templates (A0 to A4)',
            'Standardized drawing sheets compliant with ISO and ANSI specifications. Includes A0, A1, A2, A3, and A4 layouts with dynamic title blocks, revision tables, and monochrome CTB plot files.',
            499,
            399,
            isset($cat_ids['templates']) ? array($cat_ids['templates']) : array(),
            'CAD-TPL-001'
        );

        // Product 2: Simple Downloadable Structural Detailing
        $this->create_simple_downloadable_product(
            'Reinforced Concrete Structural Detailing DWG Library',
            'Full structural drawings containing rebar detailing for standard RC columns, beams, pile caps, isolated footings, and structural steel connection gusset plates.',
            1800,
            1350,
            isset($cat_ids['structural']) ? array($cat_ids['structural']) : array(),
            'CAD-STR-002'
        );

        // Product 3: Simple Downloadable BOQ Tool
        $this->create_simple_downloadable_product(
            'Building Construction BOQ & Rate Analysis Estimator',
            'Dynamic Microsoft Excel sheet template with built-in formulas, material rate analysis according to Bangladesh PWD/LGED schedules, and automated cost summaries.',
            950,
            750,
            isset($cat_ids['boq-tools']) ? array($cat_ids['boq-tools']) : array(),
            'CAD-BOQ-003'
        );

        // Product 4: Variable CAD Block Bundle
        $this->create_variable_block_product($cat_ids);

        // Product 5: Virtual Service Product
        $this->create_virtual_service_product($cat_ids);

        wp_send_json_success(array('message' => 'Sample CAD products, categories, and variable packages seeded successfully!'));
    }

    private function create_global_attributes() {
        if (!function_exists('wc_create_attribute')) return;

        // Format Attribute
        $format_attr = array(
            'name'         => 'Drawing Format',
            'slug'         => 'format',
            'type'         => 'select',
            'order_by'     => 'menu_order',
            'has_archives' => false,
        );
        wc_create_attribute($format_attr);

        // Licence Attribute
        $licence_attr = array(
            'name'         => 'Licence Type',
            'slug'         => 'licence',
            'type'         => 'select',
            'order_by'     => 'menu_order',
            'has_archives' => false,
        );
        wc_create_attribute($licence_attr);
    }

    private function create_simple_downloadable_product($title, $desc, $reg_price, $sale_price, $cat_ids, $sku) {
        $existing = wc_get_product_id_by_sku($sku);
        if ($existing) return;

        $product = new WC_Product_Simple();
        $product->set_name($title);
        $product->set_status('publish');
        $product->set_catalog_visibility('visible');
        $product->set_description($desc);
        $product->set_short_description(wp_trim_words($desc, 15));
        $product->set_sku($sku);
        $product->set_regular_price($reg_price);
        if ($sale_price) {
            $product->set_sale_price($sale_price);
            $product->set_price($sale_price);
        } else {
            $product->set_price($reg_price);
        }
        $product->set_downloadable(true);
        $product->set_virtual(true);
        $product->set_category_ids($cat_ids);
        $product->set_manage_stock(false);
        $product->set_stock_status('instock');
        $product->set_featured(true);
        $product->save();
    }

    private function create_variable_block_product($cat_ids) {
        $sku = 'CAD-BLK-VAR';
        $existing = wc_get_product_id_by_sku($sku);
        if ($existing) return;

        $product = new WC_Product_Variable();
        $product->set_name('Master Architectural CAD Block Bundle (1,500+ Blocks)');
        $product->set_status('publish');
        $product->set_description('Premium multi-tiered collection of AutoCAD dynamic blocks. Includes living room furniture, commercial sanitary fixtures, kitchen modules, landscaping trees, and 2D electrical symbols.');
        $product->set_short_description('Comprehensive library of 1,500+ AutoCAD blocks. Available in Basic, Professional, and Enterprise packages.');
        $product->set_sku($sku);
        if (isset($cat_ids['cad-blocks'])) {
            $product->set_category_ids(array($cat_ids['cad-blocks']));
        }
        $product->set_featured(true);

        // Attributes
        $attr = new WC_Product_Attribute();
        $attr->set_id(0);
        $attr->set_name('Package Tier');
        $attr->set_options(array('Basic Pack (250 Blocks)', 'Professional Pack (750 Blocks)', 'Enterprise Complete (1,500+ Blocks)'));
        $attr->set_position(0);
        $attr->set_visible(true);
        $attr->set_variation(true);
        $product->set_attributes(array($attr));
        $product_id = $product->save();

        if ($product_id) {
            // Variation 1
            $v1 = new WC_Product_Variation();
            $v1->set_parent_id($product_id);
            $v1->set_attributes(array('Package Tier' => 'Basic Pack (250 Blocks)'));
            $v1->set_regular_price(500);
            $v1->set_sale_price(399);
            $v1->set_price(399);
            $v1->set_sku('CAD-BLK-VAR-BASIC');
            $v1->set_downloadable(true);
            $v1->set_virtual(true);
            $v1->set_stock_status('instock');
            $v1->save();

            // Variation 2
            $v2 = new WC_Product_Variation();
            $v2->set_parent_id($product_id);
            $v2->set_attributes(array('Package Tier' => 'Professional Pack (750 Blocks)'));
            $v2->set_regular_price(1200);
            $v2->set_sale_price(899);
            $v2->set_price(899);
            $v2->set_sku('CAD-BLK-VAR-PRO');
            $v2->set_downloadable(true);
            $v2->set_virtual(true);
            $v2->set_stock_status('instock');
            $v2->save();

            // Variation 3
            $v3 = new WC_Product_Variation();
            $v3->set_parent_id($product_id);
            $v3->set_attributes(array('Package Tier' => 'Enterprise Complete (1,500+ Blocks)'));
            $v3->set_regular_price(2500);
            $v3->set_sale_price(1899);
            $v3->set_price(1899);
            $v3->set_sku('CAD-BLK-VAR-ENT');
            $v3->set_downloadable(true);
            $v3->set_virtual(true);
            $v3->set_stock_status('instock');
            $v3->save();
        }
    }

    private function create_virtual_service_product($cat_ids) {
        $sku = 'CAD-SRV-001';
        $existing = wc_get_product_id_by_sku($sku);
        if ($existing) return;

        $product = new WC_Product_Simple();
        $product->set_name('2D CAD Drafting & PDF-to-CAD Conversion Service (Per Sheet)');
        $product->set_status('publish');
        $product->set_description('Order professional 2D drafting for your architectural or structural sheet. Includes up to 2 revisions and delivery in both native .DWG and vector .PDF within 24 to 48 hours.');
        $product->set_short_description('Professional 2D CAD drafting and vectorization service per standard architectural sheet.');
        $product->set_sku($sku);
        $product->set_regular_price(1800);
        $product->set_sale_price(1500);
        $product->set_price(1500);
        $product->set_virtual(true);
        $product->set_downloadable(false);
        if (isset($cat_ids['services'])) {
            $product->set_category_ids(array($cat_ids['services']));
        }
        $product->set_stock_status('instock');
        $product->save();
    }
}

new CAD_Demo_Importer();
