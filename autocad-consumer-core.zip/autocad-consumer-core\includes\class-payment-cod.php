<?php
/**
 * AutoCad ConsumeR — Enhanced Cash on Delivery Gateway
 * Intelligently restricts COD to physical goods only (disables for purely digital CAD downloads).
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

class CAD_Gateway_COD extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'cad_cod';
        $this->icon               = CAD_CORE_URI . 'assets/images/cod-icon.svg';
        $this->has_fields         = false;
        $this->method_title       = __('Cash on Delivery (Physical Only)', 'autocad-consumer-core');
        $this->method_description = __('Allows customers to pay upon physical parcel delivery. Automatically disabled if cart contains only digital CAD files.', 'autocad-consumer-core');

        $this->init_form_fields();
        $this->init_settings();

        $this->title       = $this->get_option('title', 'Cash on Delivery (COD)');
        $this->description = $this->get_option('description', 'Pay in cash when you receive your physical CAD drawings, plot rolls, or USB bundle at your address.');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'autocad-consumer-core'),
                'type'    => 'checkbox',
                'label'   => __('Enable Cash on Delivery', 'autocad-consumer-core'),
                'default' => 'yes',
            ),
            'title' => array(
                'title'   => __('Title', 'autocad-consumer-core'),
                'type'    => 'text',
                'default' => __('Cash on Delivery (COD)', 'autocad-consumer-core'),
            ),
            'description' => array(
                'title'   => __('Instructions', 'autocad-consumer-core'),
                'type'    => 'textarea',
                'default' => __('Pay cash upon delivery to the courier agent. Available for printed CAD blueprint sheets and physical parcels.', 'autocad-consumer-core'),
            ),
        );
    }

    /**
     * Check if COD is available for the current cart
     * Returns false if the cart is 100% digital or virtual!
     */
    public function is_available() {
        $is_available = parent::is_available();

        if ($is_available && WC()->cart) {
            // Check if cart needs shipping
            if (!WC()->cart->needs_shipping()) {
                // Cart is 100% digital files or virtual drafting services. COD cannot be used!
                return false;
            }
        }

        return $is_available;
    }

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);

        $order->update_meta_data('_cad_payment_provider', 'Cash on Delivery');
        $order->update_meta_data('_cad_payment_verified', 'pending_collection');

        // Mark as processing (payment due upon physical delivery)
        $order->update_status('processing', __('Order placed with Cash on Delivery. Payment due upon courier delivery.', 'autocad-consumer-core'));

        wc_reduce_stock_levels($order_id);
        WC()->cart->empty_cart();

        return array(
            'result'   => 'success',
            'redirect' => $this->get_return_url($order),
        );
    }
}
