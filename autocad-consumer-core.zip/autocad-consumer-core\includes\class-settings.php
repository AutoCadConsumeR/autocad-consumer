<?php
/**
 * AutoCad ConsumeR — Admin Dashboard Widgets & Global Store Settings
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

class CAD_Admin_Settings {

    public function __construct() {
        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Dashboard Widget
        add_action('wp_dashboard_setup', array($this, 'add_dashboard_widgets'));

        // Register Settings
        add_action('admin_init', array($this, 'register_settings'));
    }

    public function add_admin_menu() {
        add_menu_page(
            __('AutoCad ConsumeR', 'autocad-consumer-core'),
            __('AutoCad ConsumeR', 'autocad-consumer-core'),
            'manage_woocommerce',
            'autocad-consumer-settings',
            array($this, 'render_settings_page'),
            'dashicons-hammer',
            56
        );

        add_submenu_page(
            'autocad-consumer-settings',
            __('Store Settings', 'autocad-consumer-core'),
            __('Store Settings', 'autocad-consumer-core'),
            'manage_woocommerce',
            'autocad-consumer-settings',
            array($this, 'render_settings_page')
        );

        add_submenu_page(
            'autocad-consumer-settings',
            __('Pending Payment Verifications', 'autocad-consumer-core'),
            __('Payment Verification', 'autocad-consumer-core'),
            'manage_woocommerce',
            'edit.php?post_type=shop_order&post_status=wc-pending-verify'
        );

        add_submenu_page(
            'autocad-consumer-settings',
            __('Sample CAD Data Importer', 'autocad-consumer-core'),
            __('Sample CAD Data', 'autocad-consumer-core'),
            'manage_woocommerce',
            'autocad-consumer-importer',
            array($this, 'render_importer_page')
        );
    }

    public function register_settings() {
        register_setting('cad_core_settings_group', 'cad_store_options');
    }

    /**
     * Dashboard Widget: AutoCad ConsumeR Store Overview
     */
    public function add_dashboard_widgets() {
        wp_add_dashboard_widget(
            'cad_store_overview_widget',
            __('📐 AutoCad ConsumeR — Engineering Store Pulse', 'autocad-consumer-core'),
            array($this, 'render_dashboard_widget')
        );
    }

    public function render_dashboard_widget() {
        $pending_verify_count = 0;
        $flagged_count        = 0;
        $total_orders         = 0;
        $total_sales          = '৳0.00';

        if (function_exists('wc_get_orders')) {
            $pending_orders = wc_get_orders(array('status' => 'wc-pending-verify', 'limit' => -1));
            $pending_verify_count = count($pending_orders);

            $flagged_orders = wc_get_orders(array('meta_key' => '_cad_fraud_flagged', 'meta_value' => 'yes', 'limit' => -1));
            $flagged_count = count($flagged_orders);

            $all_orders = wc_get_orders(array('limit' => -1));
            $total_orders = count($all_orders);
        }
        ?>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:16px;">
            <div style="background:#F8FAFC; border:1px solid #E2E8F0; padding:12px; border-radius:6px; text-align:center;">
                <div style="font-size:1.6rem; font-weight:800; color:#1769AA;"><?php echo esc_html($total_orders); ?></div>
                <div style="font-size:0.75rem; color:#64748B; font-weight:600; text-transform:uppercase;"><?php esc_html_e('Total Orders', 'autocad-consumer-core'); ?></div>
            </div>
            <div style="background:#FFFBEB; border:1px solid #FCD34D; padding:12px; border-radius:6px; text-align:center;">
                <div style="font-size:1.6rem; font-weight:800; color:#D97706;"><?php echo esc_html($pending_verify_count); ?></div>
                <div style="font-size:0.75rem; color:#92400E; font-weight:600; text-transform:uppercase;"><?php esc_html_e('Pending Payments', 'autocad-consumer-core'); ?></div>
            </div>
            <div style="background:#FEF2F2; border:1px solid #FCA5A5; padding:12px; border-radius:6px; text-align:center;">
                <div style="font-size:1.6rem; font-weight:800; color:#E50914;"><?php echo esc_html($flagged_count); ?></div>
                <div style="font-size:0.75rem; color:#991B1B; font-weight:600; text-transform:uppercase;"><?php esc_html_e('Security Flagged', 'autocad-consumer-core'); ?></div>
            </div>
            <div style="background:#ECFDF5; border:1px solid #A7F3D0; padding:12px; border-radius:6px; text-align:center;">
                <div style="font-size:1.6rem; font-weight:800; color:#059669;">BDT (৳)</div>
                <div style="font-size:0.75rem; color:#065F46; font-weight:600; text-transform:uppercase;"><?php esc_html_e('Active Currency', 'autocad-consumer-core'); ?></div>
            </div>
        </div>

        <?php if ($pending_verify_count > 0) : ?>
            <p style="margin-bottom:8px;">
                <a href="<?php echo esc_url(admin_url('edit.php?post_type=shop_order&post_status=wc-pending-verify')); ?>" class="button button-primary" style="background:#D97706; border-color:#B45309; width:100%; text-align:center;">
                    <?php printf(esc_html__('Review %d Pending Mobile Payments →', 'autocad-consumer-core'), $pending_verify_count); ?>
                </a>
            </p>
        <?php endif; ?>

        <div style="border-top:1px solid #E2E8F0; padding-top:10px; font-size:0.8125rem; display:flex; justify-content:space-between;">
            <a href="<?php echo esc_url(admin_url('admin.php?page=autocad-consumer-settings')); ?>"><?php esc_html_e('Configure Payment Numbers', 'autocad-consumer-core'); ?></a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=autocad-consumer-importer')); ?>"><?php esc_html_e('Sample CAD Seeder', 'autocad-consumer-core'); ?></a>
        </div>
        <?php
    }

    public function render_settings_page() {
        $active_tab = isset($_GET['tab']) ? sanitize_text_field(wp_unslash($_GET['tab'])) : 'gateways';
        ?>
        <div class="wrap">
            <h1 style="display:flex; align-items:center; gap:12px;">
                <img src="<?php echo esc_url(CAD_CORE_URI . 'assets/images/logo.png'); ?>" alt="AutoCad ConsumeR" style="max-height:42px; width:auto;" />
                <?php esc_html_e('AutoCad ConsumeR Administration', 'autocad-consumer-core'); ?>
            </h1>

            <h2 class="nav-tab-wrapper" style="margin-top:20px;">
                <a href="?page=autocad-consumer-settings&tab=gateways" class="nav-tab <?php echo $active_tab === 'gateways' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e('Mobile Payment Numbers (bKash/Nagad/Rocket)', 'autocad-consumer-core'); ?></a>
                <a href="?page=autocad-consumer-settings&tab=fraud" class="nav-tab <?php echo $active_tab === 'fraud' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e('Anti-Fake-Order Protection', 'autocad-consumer-core'); ?></a>
                <a href="?page=autocad-consumer-settings&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e('Store & Brand Info', 'autocad-consumer-core'); ?></a>
            </h2>

            <?php if ($active_tab === 'gateways') : ?>
                <div style="background:#fff; border:1px solid #ccd0d4; padding:24px; border-radius:8px; margin-top:20px; max-width:800px;">
                    <h3><?php esc_html_e('Configure Manual Send Money Gateways', 'autocad-consumer-core'); ?></h3>
                    <p style="color:#64748B;">
                        <?php esc_html_e('To change the recipient number, instructions, or account types shown on the checkout page, click the gateway links below. All updates reflect instantly on customer checkout screens without modifying code.', 'autocad-consumer-core'); ?>
                    </p>

                    <div style="display:grid; grid-template-columns:1fr; gap:16px; margin-top:20px;">
                        <div style="border:1px solid #E2E8F0; padding:16px; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
                            <div>
                                <h4 style="margin:0 0 4px; color:#E2136E; font-size:1.1rem;">bKash Send Money</h4>
                                <span style="font-size:0.8125rem; color:#64748B;"><?php esc_html_e('Configurable recipient number, instructions, and QR code.', 'autocad-consumer-core'); ?></span>
                            </div>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=cad_bkash')); ?>" class="button button-primary" style="background:#E2136E; border-color:#C2185B;">
                                <?php esc_html_e('Edit bKash Settings →', 'autocad-consumer-core'); ?>
                            </a>
                        </div>

                        <div style="border:1px solid #E2E8F0; padding:16px; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
                            <div>
                                <h4 style="margin:0 0 4px; color:#F7941D; font-size:1.1rem;">Nagad Send Money</h4>
                                <span style="font-size:0.8125rem; color:#64748B;"><?php esc_html_e('Configurable recipient number, instructions, and account type.', 'autocad-consumer-core'); ?></span>
                            </div>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=cad_nagad')); ?>" class="button button-primary" style="background:#F7941D; border-color:#E65100;">
                                <?php esc_html_e('Edit Nagad Settings →', 'autocad-consumer-core'); ?>
                            </a>
                        </div>

                        <div style="border:1px solid #E2E8F0; padding:16px; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
                            <div>
                                <h4 style="margin:0 0 4px; color:#8C3494; font-size:1.1rem;">Rocket (DBBL) Send Money</h4>
                                <span style="font-size:0.8125rem; color:#64748B;"><?php esc_html_e('Configurable 12-digit number and instructions.', 'autocad-consumer-core'); ?></span>
                            </div>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=cad_rocket')); ?>" class="button button-primary" style="background:#8C3494; border-color:#6A1B9A;">
                                <?php esc_html_e('Edit Rocket Settings →', 'autocad-consumer-core'); ?>
                            </a>
                        </div>

                        <div style="border:1px solid #E2E8F0; padding:16px; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
                            <div>
                                <h4 style="margin:0 0 4px; color:#1769AA; font-size:1.1rem;">Cash on Delivery (Physical Only)</h4>
                                <span style="font-size:0.8125rem; color:#64748B;"><?php esc_html_e('Automatically disabled for purely digital CAD downloads.', 'autocad-consumer-core'); ?></span>
                            </div>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout&section=cad_cod')); ?>" class="button button-secondary">
                                <?php esc_html_e('Edit COD Settings →', 'autocad-consumer-core'); ?>
                            </a>
                        </div>
                    </div>
                </div>

            <?php elseif ($active_tab === 'fraud') : ?>
                <div style="background:#fff; border:1px solid #ccd0d4; padding:24px; border-radius:8px; margin-top:20px; max-width:800px;">
                    <h3><?php esc_html_e('Active Anti-Fake-Order Protection Safeguards', 'autocad-consumer-core'); ?></h3>
                    <ul style="list-style:disc; margin-left:20px; color:#1E293B; line-height:1.7;">
                        <li><strong><?php esc_html_e('Bangladeshi Mobile Phone Validation:', 'autocad-consumer-core'); ?></strong> <?php esc_html_e('Checks every checkout phone number against valid prefixes (013, 014, 015, 016, 017, 018, 019) with exact 11-digit structure.', 'autocad-consumer-core'); ?></li>
                        <li><strong><?php esc_html_e('Rate Limiting Transient Shield:', 'autocad-consumer-core'); ?></strong> <?php esc_html_e('Prevents scripted bot spam by throttling order requests per IP address.', 'autocad-consumer-core'); ?></li>
                        <li><strong><?php esc_html_e('24-Hour Duplicate Order Detection:', 'autocad-consumer-core'); ?></strong> <?php esc_html_e('Flags any customer attempting multiple duplicate orders with identical phone numbers in 24 hours without blocking valid checkouts.', 'autocad-consumer-core'); ?></li>
                        <li><strong><?php esc_html_e('High-Value COD Flagging:', 'autocad-consumer-core'); ?></strong> <?php esc_html_e('COD orders over ৳5,000 are automatically highlighted for mandatory verbal phone verification prior to parcel dispatch.', 'autocad-consumer-core'); ?></li>
                        <li><strong><?php esc_html_e('Audit Trail Logging:', 'autocad-consumer-core'); ?></strong> <?php esc_html_e('Records admin approval timestamps and identity directly in WooCommerce order meta.', 'autocad-consumer-core'); ?></li>
                    </ul>
                </div>

            <?php elseif ($active_tab === 'general') : ?>
                <div style="background:#fff; border:1px solid #ccd0d4; padding:24px; border-radius:8px; margin-top:20px; max-width:800px;">
                    <h3><?php esc_html_e('Brand Identity & Live Customizer', 'autocad-consumer-core'); ?></h3>
                    <p>
                        <?php esc_html_e('You can customize the logo, hotline, WhatsApp number, engineering office address, and social links using the WordPress Customizer live preview.', 'autocad-consumer-core'); ?>
                    </p>
                    <a href="<?php echo esc_url(admin_url('customize.php')); ?>" class="button button-primary">
                        <?php esc_html_e('Open Live Customizer →', 'autocad-consumer-core'); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    public function render_importer_page() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Sample CAD Products & Categories Seeder', 'autocad-consumer-core'); ?></h1>
            <div style="background:#fff; border:1px solid #ccd0d4; padding:24px; border-radius:8px; margin-top:20px; max-width:760px;">
                <p>
                    <?php esc_html_e('With 1-click, you can seed production-ready sample CAD products, complete with variable pricing, DWG/DXF attributes, categories, and BDT currency values.', 'autocad-consumer-core'); ?>
                </p>
                <div id="cadSeederNotice" style="margin-bottom:18px;"></div>
                <button type="button" id="cadRunSeederBtn" class="button button-primary button-hero" style="background:#E50914; border-color:#B8000A;">
                    <?php esc_html_e('⚡ Populate Sample CAD Products & Categories', 'autocad-consumer-core'); ?>
                </button>
            </div>
        </div>
        <?php
    }
}

new CAD_Admin_Settings();
