/**
 * AutoCad ConsumeR Core — Admin Script
 */
(function($) {
  'use strict';

  $(document).ready(function() {
    // 1. Payment Verification Button
    $(document).on('click', '.cad-action-verify', function(e) {
      e.preventDefault();
      var $btn = $(this);
      var orderId = $btn.data('order-id');

      if (!confirm('Are you sure you want to approve this payment? This will mark the order completed and unlock digital download permissions immediately.')) {
        return;
      }

      $btn.prop('disabled', true).text('Verifying...');

      $.post(cadAdminData.ajaxUrl, {
        action: 'cad_verify_order_payment',
        order_id: orderId,
        nonce: cadAdminData.nonce
      }, function(res) {
        if (res && res.success) {
          alert(res.data.message);
          window.location.reload();
        } else {
          alert('Error: ' + (res.data ? res.data.message : 'Failed'));
          $btn.prop('disabled', false).text('✓ Approve Payment');
        }
      });
    });

    // 2. Payment Rejection Button
    $(document).on('click', '.cad-action-reject', function(e) {
      e.preventDefault();
      var $btn = $(this);
      var orderId = $btn.data('order-id');

      if (!confirm('Reject this payment reference as invalid? The order will be put on-hold.')) {
        return;
      }

      $btn.prop('disabled', true).text('Rejecting...');

      $.post(cadAdminData.ajaxUrl, {
        action: 'cad_reject_order_payment',
        order_id: orderId,
        nonce: cadAdminData.nonce
      }, function(res) {
        if (res && res.success) {
          alert(res.data.message);
          window.location.reload();
        } else {
          alert('Error: ' + (res.data ? res.data.message : 'Failed'));
          $btn.prop('disabled', false).text('✕ Reject');
        }
      });
    });

    // 3. Sample CAD Data Seeder Button
    $('#cadRunSeederBtn').on('click', function(e) {
      e.preventDefault();
      var $btn = $(this);
      var $notice = $('#cadSeederNotice');

      $btn.prop('disabled', true).text('⚡ Seeding CAD Catalog Products...');
      $notice.html('<div class="notice notice-info"><p>Creating sample CAD products, DWG templates, and variable packages...</p></div>');

      $.post(cadAdminData.ajaxUrl, {
        action: 'cad_run_sample_seeder',
        nonce: cadAdminData.nonce
      }, function(res) {
        $btn.prop('disabled', false).text('⚡ Populate Sample CAD Products & Categories');
        if (res && res.success) {
          $notice.html('<div class="notice notice-success is-dismissible"><p><strong>' + res.data.message + '</strong> Visit <a href="/wp-admin/edit.php?post_type=product">Products list</a> to view them!</p></div>');
        } else {
          $notice.html('<div class="notice notice-error"><p>' + (res.data ? res.data.message : 'Error seeding catalog') + '</p></div>');
        }
      });
    });
  });

})(jQuery);
