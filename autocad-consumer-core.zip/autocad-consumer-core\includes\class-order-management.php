<?php
/**
 * AutoCad ConsumeR — Order Management, Payment Verification & Audit Log
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

class CAD_Order_Management {

    public function __construct() {
        // Add metabox to WooCommerce Order Edit screen
        add_action('add_meta_boxes', array($this, 'add_order_verification_metabox'));

        // AJAX verification actions
        add_action('wp_ajax_cad_verify_order_payment', array($this, 'ajax_verify_payment'));
        add_action('wp_ajax_cad_reject_order_payment', array($this, 'ajax_reject_payment'));

        // Order List Reference Column
        add_filter('manage_edit-shop_order_columns', array($this, 'add_order_ref_column'));
        add_action('manage_shop_order_posts_custom_column', array($this, 'render_order_ref_column'), 10, 2);
    }

    public function add_order_verification_metabox() {
        $screen = class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()
            ? wc_get_page_screen_id('shop-order')
            : 'shop_order';

        add_meta_box(
            'cad_order_verification_box',
            __('AutoCad ConsumeR — Payment Reference & Verification', 'autocad-consumer-core'),
            array($this, 'render_verification_metabox'),
            $screen,
            'side',
            'high'
        );
    }

    public function render_verification_metabox($post_or_order) {
        $order = ($post_or_order instanceof WC_Order) ? $post_or_order : wc_get_order($post_or_order->ID);
        if (!$order) return;

        $provider    = $order->get_meta('_cad_payment_provider');
        $recipient   = $order->get_meta('_cad_payment_recipient');
        $sender      = $order->get_meta('_cad_payment_sender_number');
        $trxid       = $order->get_meta('_cad_payment_trxid');
        $verified    = $order->get_meta('_cad_payment_verified');
        $audit_log   = $order->get_meta('_cad_verification_audit');
        $customer_id = $order->get_customer_id();

        // Customer History Count
        $customer_orders_count = 0;
        if ($customer_id) {
            $customer_orders = wc_get_orders(array('customer' => $customer_id, 'limit' => -1));
            $customer_orders_count = count($customer_orders);
        }
        ?>
        <div class="cad-admin-metabox">
            <?php if (empty($provider)) : ?>
                <p style="color:#64748B;"><?php esc_html_e('Standard payment method used (No manual Send Money reference required).', 'autocad-consumer-core'); ?></p>
            <?php else : ?>
                <table style="width:100%; font-size:0.875rem; border-collapse:collapse; margin-bottom:14px;">
                    <tr>
                        <td style="padding:4px 0; color:#64748B;"><strong><?php esc_html_e('Provider:', 'autocad-consumer-core'); ?></strong></td>
                        <td style="padding:4px 0;"><span style="font-weight:bold; color:#1769AA;"><?php echo esc_html($provider); ?></span></td>
                    </tr>
                    <tr>
                        <td style="padding:4px 0; color:#64748B;"><strong><?php esc_html_e('Sent to:', 'autocad-consumer-core'); ?></strong></td>
                        <td style="padding:4px 0; font-family:monospace;"><?php echo esc_html($recipient ? $recipient : 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <td style="padding:4px 0; color:#64748B;"><strong><?php esc_html_e('Sender Number:', 'autocad-consumer-core'); ?></strong></td>
                        <td style="padding:4px 0; font-family:monospace; font-weight:bold;"><?php echo esc_html($sender ? $sender : 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <td style="padding:4px 0; color:#64748B;"><strong><?php esc_html_e('TrxID:', 'autocad-consumer-core'); ?></strong></td>
                        <td style="padding:4px 0;"><span style="background:#FEF2F2; color:#E50914; padding:2px 6px; border-radius:3px; font-family:monospace; font-weight:bold; font-size:0.95rem;"><?php echo esc_html($trxid ? $trxid : 'N/A'); ?></span></td>
                    </tr>
                    <tr>
                        <td style="padding:4px 0; color:#64748B;"><strong><?php esc_html_e('Status:', 'autocad-consumer-core'); ?></strong></td>
                        <td style="padding:4px 0;">
                            <?php if ($verified === 'yes') : ?>
                                <span style="color:#10B981; font-weight:bold;">✓ <?php esc_html_e('VERIFIED & APPROVED', 'autocad-consumer-core'); ?></span>
                            <?php else : ?>
                                <span style="color:#D97706; font-weight:bold;">⏳ <?php esc_html_e('PENDING VERIFICATION', 'autocad-consumer-core'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>

                <?php if ($verified !== 'yes') : ?>
                    <div style="display:flex; flex-direction:column; gap:8px; margin-top:14px; border-top:1px solid #E2E8F0; padding-top:12px;">
                        <button type="button" class="button button-primary cad-action-verify" data-order-id="<?php echo esc_attr($order->get_id()); ?>" style="background:#10B981; border-color:#059669; font-weight:bold;">
                            <?php esc_html_e('✓ Approve Payment & Unlock Files', 'autocad-consumer-core'); ?>
                        </button>
                        <button type="button" class="button cad-action-reject" data-order-id="<?php echo esc_attr($order->get_id()); ?>" style="color:#DC2626; border-color:#FCA5A5;">
                            <?php esc_html_e('✕ Reject (Invalid Reference)', 'autocad-consumer-core'); ?>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if (!empty($audit_log)) : ?>
                    <div style="margin-top:12px; font-size:0.75rem; color:#64748B; background:#F8FAFC; padding:8px; border-radius:4px;">
                        <strong><?php esc_html_e('Audit Trail:', 'autocad-consumer-core'); ?></strong><br>
                        <?php echo esc_html($audit_log); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div style="margin-top:16px; border-top:1px solid #E2E8F0; padding-top:10px; font-size:0.8125rem; color:#64748B;">
                <strong><?php esc_html_e('Customer History:', 'autocad-consumer-core'); ?></strong> <?php echo esc_html($customer_orders_count); ?> <?php esc_html_e('total order(s)', 'autocad-consumer-core'); ?>
            </div>
        </div>
        <?php
    }

    public function ajax_verify_payment() {
        check_ajax_referer('cad_admin_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'Permission denied.'));
        }

        $order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
        $order = wc_get_order($order_id);

        if ($order) {
            $current_user = wp_get_current_user();
            $timestamp = current_time('mysql');
            $audit_msg = sprintf(__('Verified by %s on %s', 'autocad-consumer-core'), $current_user->display_name, $timestamp);

            $order->update_meta_data('_cad_payment_verified', 'yes');
            $order->update_meta_data('_cad_verification_audit', $audit_msg);

            // Set to Completed (or Processing)
            $order->update_status('completed', sprintf(__('Payment verified and approved by %s. Digital downloads unlocked.', 'autocad-consumer-core'), $current_user->display_name));
            $order->save();

            wp_send_json_success(array('message' => 'Payment verified! Order marked completed.'));
        }

        wp_send_json_error(array('message' => 'Invalid order.'));
    }

    public function ajax_reject_payment() {
        check_ajax_referer('cad_admin_nonce', 'nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => 'Permission denied.'));
        }

        $order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
        $order = wc_get_order($order_id);

        if ($order) {
            $current_user = wp_get_current_user();
            $order->update_meta_data('_cad_payment_verified', 'rejected');
            $order->update_status('on-hold', sprintf(__('Payment reference rejected as invalid/unmatched by %s.', 'autocad-consumer-core'), $current_user->display_name));
            $order->save();

            wp_send_json_success(array('message' => 'Payment reference rejected. Order placed on-hold.'));
        }

        wp_send_json_error(array('message' => 'Invalid order.'));
    }

    public function add_order_ref_column($columns) {
        $new_columns = array();
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;
            if ('order_total' === $key) {
                $new_columns['cad_trx_ref'] = __('Payment Reference', 'autocad-consumer-core');
            }
        }
        return $new_columns;
    }

    public function render_order_ref_column($column, $post_id) {
        if ('cad_trx_ref' === $column) {
            $order = wc_get_order($post_id);
            if (!$order) return;

            $provider = $order->get_meta('_cad_payment_provider');
            $trxid    = $order->get_meta('_cad_payment_trxid');
            $verified = $order->get_meta('_cad_payment_verified');

            if (!empty($provider) && !empty($trxid)) {
                $badge_color = ($verified === 'yes') ? '#059669' : '#D97706';
                echo '<div style="font-size:0.8125rem;">';
                echo '<strong>' . esc_html($provider) . '</strong>: <span style="font-family:monospace; color:#E50914;">' . esc_html($trxid) . '</span><br>';
                echo '<span style="color:' . esc_attr($badge_color) . '; font-size:0.75rem;">' . ($verified === 'yes' ? '✓ Verified' : '⏳ Pending') . '</span>';
                echo '</div>';
            } else {
                echo '<span style="color:#94A3B8; font-size:0.75rem;">—</span>';
            }
        }
    }
}

new CAD_Order_Management();
