<?php
/**
 * AutoCad ConsumeR — Custom CAD Drafting Quote Request Handler
 *
 * @package AutoCad_ConsumeR_Core
 */

if (!defined('ABSPATH')) {
    exit;
}

class CAD_Service_Quote {

    public function __construct() {
        // Register Custom Post Type for Quotes
        add_action('init', array($this, 'register_quote_cpt'));

        // Handle AJAX submission
        add_action('wp_ajax_cad_submit_quote_request', array($this, 'handle_quote_submission'));
        add_action('wp_ajax_nopriv_cad_submit_quote_request', array($this, 'handle_quote_submission'));
    }

    public function register_quote_cpt() {
        register_post_type('cad_quote', array(
            'labels' => array(
                'name'               => __('CAD Quote Inquiries', 'autocad-consumer-core'),
                'singular_name'      => __('CAD Quote', 'autocad-consumer-core'),
                'menu_name'          => __('CAD Quotes', 'autocad-consumer-core'),
                'all_items'          => __('All Quote Requests', 'autocad-consumer-core'),
                'view_item'          => __('View Quote', 'autocad-consumer-core'),
                'search_items'       => __('Search Quotes', 'autocad-consumer-core'),
            ),
            'public'       => false,
            'show_ui'      => true,
            'show_in_menu' => 'autocad-consumer-settings',
            'supports'     => array('title', 'custom-fields'),
            'capability_type' => 'post',
        ));
    }

    public function handle_quote_submission() {
        check_ajax_referer('cad_quote_nonce', 'nonce');

        // Bot honeypot check
        if (!empty($_POST['cad_website_hp'])) {
            wp_send_json_success(array('message' => 'Quote received.'));
        }

        $name    = isset($_POST['quote_name']) ? sanitize_text_field(wp_unslash($_POST['quote_name'])) : '';
        $phone   = isset($_POST['quote_phone']) ? sanitize_text_field(wp_unslash($_POST['quote_phone'])) : '';
        $email   = isset($_POST['quote_email']) ? sanitize_email(wp_unslash($_POST['quote_email'])) : '';
        $service = isset($_POST['quote_service']) ? sanitize_text_field(wp_unslash($_POST['quote_service'])) : '';
        $scope   = isset($_POST['quote_scope']) ? sanitize_textarea_field(wp_unslash($_POST['quote_scope'])) : '';

        if (empty($name) || empty($phone) || empty($email) || empty($scope)) {
            wp_send_json_error(array('message' => 'Please fill in all required fields.'));
        }

        // Validate Bangladeshi phone
        $phone_clean = preg_replace('/[^0-9]/', '', $phone);
        if (substr($phone_clean, 0, 3) === '880') {
            $phone_clean = substr($phone_clean, 2);
        }
        if (!preg_match('/^(01)[3-9]{1}[0-9]{8}$/', $phone_clean)) {
            wp_send_json_error(array('message' => 'Please provide a valid 11-digit Bangladeshi mobile number (01XXXXXXXXX).'));
        }

        // File upload handling
        $file_url = '';
        if (!empty($_FILES['quote_file']['name'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';

            $allowed_exts = array('pdf', 'dwg', 'dxf', 'zip', 'png', 'jpg', 'jpeg');
            $file_info    = wp_check_filetype(basename($_FILES['quote_file']['name']), null);
            $ext          = strtolower($file_info['ext']);

            if (!in_array($ext, $allowed_exts, true)) {
                wp_send_json_error(array('message' => 'Invalid file extension. Allowed formats: .dwg, .dxf, .pdf, .zip, .png, .jpg'));
            }

            // Check size (25MB limit)
            if ($_FILES['quote_file']['size'] > 25 * 1024 * 1024) {
                wp_send_json_error(array('message' => 'File size exceeds maximum allowable limit of 25MB.'));
            }

            $upload = wp_handle_upload($_FILES['quote_file'], array('test_form' => false));
            if (!empty($upload['url'])) {
                $file_url = esc_url_raw($upload['url']);
            }
        }

        // Save Quote CPT Entry
        $post_id = wp_insert_post(array(
            'post_type'   => 'cad_quote',
            'post_status' => 'publish',
            'post_title'  => sprintf('Quote Request #%s — %s (%s)', gmdate('mdHis'), $name, $service),
        ));

        if ($post_id && !is_wp_error($post_id)) {
            update_post_meta($post_id, '_cad_quote_client_name', $name);
            update_post_meta($post_id, '_cad_quote_phone', $phone);
            update_post_meta($post_id, '_cad_quote_email', $email);
            update_post_meta($post_id, '_cad_quote_service', $service);
            update_post_meta($post_id, '_cad_quote_scope', $scope);
            if (!empty($file_url)) {
                update_post_meta($post_id, '_cad_quote_attachment', $file_url);
            }

            // Notify admin via email
            $admin_email = get_option('admin_email');
            $subject     = sprintf('[AutoCad ConsumeR] New CAD Quote Request from %s', $name);
            $message     = "You have received a new CAD Drafting Quote Request:\n\n" .
                           "Client Name: $name\n" .
                           "Phone: $phone\n" .
                           "Email: $email\n" .
                           "Service: $service\n\n" .
                           "Scope & Instructions:\n$scope\n\n" .
                           ($file_url ? "Attachment: $file_url\n\n" : "") .
                           "Manage Quotes in Admin: " . admin_url('edit.php?post_type=cad_quote');

            wp_mail($admin_email, $subject, $message);

            wp_send_json_success(array('message' => 'Thank you! Your CAD drafting specifications have been received. Our senior CAD technician will review and reply within 4 hours.'));
        }

        wp_send_json_error(array('message' => 'Database error while saving inquiry.'));
    }
}

new CAD_Service_Quote();
