/**
 * AutoCad ConsumeR Core — Checkout Gateway Helper
 */
(function($) {
  'use strict';

  $(document).ready(function() {
    // Uppercase TrxID automatically as user types
    $(document).on('input', '#cad_bkash_trxid, #cad_nagad_trxid, #cad_rocket_trxid', function() {
      this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    });

    // Auto format 11-digit phone numbers
    $(document).on('input', '#cad_bkash_sender_number, #cad_nagad_sender_number, #billing_phone', function() {
      this.value = this.value.replace(/[^0-9]/g, '');
    });
  });

})(jQuery);
