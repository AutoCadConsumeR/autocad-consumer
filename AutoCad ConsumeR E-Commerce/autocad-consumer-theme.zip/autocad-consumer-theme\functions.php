<?php
/**
 * AutoCad ConsumeR — Theme Functions and Definitions
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

define('AUTOCAD_CONSUMER_VERSION', '1.0.0');
define('AUTOCAD_CONSUMER_DIR', get_template_directory());
define('AUTOCAD_CONSUMER_URI', get_template_directory_uri());

/**
 * Theme Setup
 */
function autocad_consumer_setup() {
    // Make theme available for translation
    load_theme_textdomain('autocad-consumer', AUTOCAD_CONSUMER_DIR . '/languages');

    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');

    // Let WordPress manage document title
    add_theme_support('title-tag');

    // Enable support for Post Thumbnails on posts and pages
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(600, 450, true);

    // Register navigation menus
    register_nav_menus(array(
        'primary'   => __('Primary CAD Navigation', 'autocad-consumer'),
        'topbar'    => __('Top Bar Menu', 'autocad-consumer'),
        'footer'    => __('Footer Legal & Policies', 'autocad-consumer'),
        'categories'=> __('Header CAD Categories', 'autocad-consumer'),
    ));

    // HTML5 markup support
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));

    // Custom Logo Support
    add_theme_support('custom-logo', array(
        'height'      => 60,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // WooCommerce Support
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'autocad_consumer_setup');

/**
 * Enqueue Styles and Scripts
 */
function autocad_consumer_scripts() {
    // Google Fonts: Inter, Rajdhani, JetBrains Mono
    wp_enqueue_style(
        'autocad-consumer-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700;800&family=Rajdhani:wght@600;700;800&display=swap',
        array(),
        null
    );

    // Theme CSS
    wp_enqueue_style('autocad-consumer-base', get_stylesheet_uri(), array(), AUTOCAD_CONSUMER_VERSION);
    wp_enqueue_style('autocad-consumer-header-drawer', AUTOCAD_CONSUMER_URI . '/assets/css/header-cart-drawer.css', array('autocad-consumer-base'), AUTOCAD_CONSUMER_VERSION);
    wp_enqueue_style('autocad-consumer-main', AUTOCAD_CONSUMER_URI . '/assets/css/main.css', array('autocad-consumer-header-drawer'), AUTOCAD_CONSUMER_VERSION);
    wp_enqueue_style('autocad-consumer-carousel', AUTOCAD_CONSUMER_URI . '/assets/css/carousel.css', array('autocad-consumer-main'), AUTOCAD_CONSUMER_VERSION);

    if (class_exists('WooCommerce')) {
        wp_enqueue_style('autocad-consumer-wc', AUTOCAD_CONSUMER_URI . '/assets/css/woocommerce-custom.css', array('autocad-consumer-main'), AUTOCAD_CONSUMER_VERSION);
    }

    // Theme Scripts (jQuery dependent)
    wp_enqueue_script('jquery');
    wp_enqueue_script('autocad-consumer-drawer', AUTOCAD_CONSUMER_URI . '/assets/js/cart-drawer.js', array('jquery'), AUTOCAD_CONSUMER_VERSION, true);
    wp_enqueue_script('autocad-consumer-carousel', AUTOCAD_CONSUMER_URI . '/assets/js/carousel.js', array(), AUTOCAD_CONSUMER_VERSION, true);
    wp_enqueue_script('autocad-consumer-main', AUTOCAD_CONSUMER_URI . '/assets/js/main.js', array('jquery'), AUTOCAD_CONSUMER_VERSION, true);

    if (is_product()) {
        wp_enqueue_script('autocad-consumer-variations', AUTOCAD_CONSUMER_URI . '/assets/js/variations-enhancer.js', array('jquery'), AUTOCAD_CONSUMER_VERSION, true);
    }

    // Localize Data for AJAX
    wp_localize_script('autocad-consumer-main', 'cadStoreData', array(
        'ajaxUrl'        => admin_url('admin-ajax.php'),
        'nonce'          => wp_create_nonce('cad_store_nonce'),
        'quoteNonce'     => wp_create_nonce('cad_quote_nonce'),
        'currencySymbol' => '৳',
        'isLoggedIn'     => is_user_logged_in(),
    ));
}
add_action('wp_enqueue_scripts', 'autocad_consumer_scripts');

/**
 * Require Inc Files
 */
require_once AUTOCAD_CONSUMER_DIR . '/inc/customizer.php';
require_once AUTOCAD_CONSUMER_DIR . '/inc/template-tags.php';
require_once AUTOCAD_CONSUMER_DIR . '/inc/woocommerce-setup.php';
