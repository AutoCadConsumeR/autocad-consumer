<?php
/**
 * AutoCad ConsumeR — Standard Page Template
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="cad-container" style="padding-top:40px; padding-bottom:60px;">
    <?php
    while (have_posts()) :
        the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="cad-page-header" style="margin-bottom:30px; border-bottom:1px solid var(--cad-border-light); padding-bottom:16px;">
                <h1 class="cad-section-title" style="margin:0;"><?php the_title(); ?></h1>
            </header>

            <div class="cad-entry-content" style="line-height:1.7; font-size:1rem; color:var(--cad-text-main);">
                <?php the_content(); ?>
            </div>
        </article>
        <?php
    endwhile;
    ?>
</div>

<?php
get_footer();
