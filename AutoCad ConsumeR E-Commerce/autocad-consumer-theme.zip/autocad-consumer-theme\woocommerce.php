<?php
/**
 * AutoCad ConsumeR — WooCommerce Wrapper Template
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="cad-container" style="padding-top:40px; padding-bottom:70px;">
    <?php
    if (function_exists('woocommerce_content')) {
        woocommerce_content();
    }
    ?>
</div>

<?php
get_footer();
