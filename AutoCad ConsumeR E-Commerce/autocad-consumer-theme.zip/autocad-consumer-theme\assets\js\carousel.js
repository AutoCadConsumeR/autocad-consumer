/**
 * AutoCad ConsumeR — Featured Product Carousel Controller
 * Touch/drag support, responsive sliding, autoplay with hover pause, and prefers-reduced-motion check.
 */
(function() {
  'use strict';

  function initCarousel() {
    var container = document.querySelector('.cad-featured-carousel-section');
    if (!container) return;

    var track = container.querySelector('.cad-carousel-track');
    var slides = container.querySelectorAll('.cad-carousel-slide');
    var prevBtn = container.querySelector('.cad-carousel-prev');
    var nextBtn = container.querySelector('.cad-carousel-next');
    var dotsContainer = container.querySelector('.cad-carousel-dots');
    var viewport = container.querySelector('.cad-carousel-viewport');

    if (!track || slides.length === 0) return;

    var currentIndex = 0;
    var slideWidth = 0;
    var visibleCount = 3;
    var totalSlides = slides.length;
    var autoplayTimer = null;
    var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function getVisibleCount() {
      var w = window.innerWidth;
      if (w < 640) return 1;
      if (w < 992) return 2;
      return 3;
    }

    function maxIndex() {
      return Math.max(0, totalSlides - visibleCount);
    }

    function updateMetrics() {
      visibleCount = getVisibleCount();
      var viewportWidth = viewport.clientWidth;
      var gap = 24;
      var calculatedWidth = (viewportWidth - (gap * (visibleCount - 1))) / visibleCount;
      
      slides.forEach(function(slide) {
        slide.style.flex = '0 0 ' + calculatedWidth + 'px';
      });

      slideWidth = calculatedWidth + gap;
      goToSlide(Math.min(currentIndex, maxIndex()));
      buildDots();
    }

    function buildDots() {
      if (!dotsContainer) return;
      dotsContainer.innerHTML = '';
      var numDots = maxIndex() + 1;
      if (numDots <= 1) return;

      for (var i = 0; i < numDots; i++) {
        var dot = document.createElement('button');
        dot.className = 'cad-carousel-dot' + (i === currentIndex ? ' active' : '');
        dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
        (function(index) {
          dot.addEventListener('click', function() {
            goToSlide(index);
          });
        })(i);
        dotsContainer.appendChild(dot);
      }
    }

    function updateDots() {
      if (!dotsContainer) return;
      var dots = dotsContainer.querySelectorAll('.cad-carousel-dot');
      dots.forEach(function(dot, idx) {
        if (idx === currentIndex) {
          dot.classList.add('active');
        } else {
          dot.classList.remove('active');
        }
      });
    }

    function goToSlide(index) {
      currentIndex = Math.max(0, Math.min(index, maxIndex()));
      var offset = -(currentIndex * slideWidth);
      track.style.transform = 'translateX(' + offset + 'px)';
      updateDots();
    }

    function nextSlide() {
      if (currentIndex >= maxIndex()) {
        goToSlide(0);
      } else {
        goToSlide(currentIndex + 1);
      }
    }

    function prevSlide() {
      if (currentIndex <= 0) {
        goToSlide(maxIndex());
      } else {
        goToSlide(currentIndex - 1);
      }
    }

    if (nextBtn) nextBtn.addEventListener('click', nextSlide);
    if (prevBtn) prevBtn.addEventListener('click', prevSlide);

    // Touch & Drag Handling
    var isDragging = false;
    var startPos = 0;
    var currentTranslate = 0;
    var prevTranslate = 0;

    function getPositionX(e) {
      return e.type.includes('mouse') ? e.pageX : e.touches[0].clientX;
    }

    function dragStart(e) {
      isDragging = true;
      startPos = getPositionX(e);
      track.style.transition = 'none';
      stopAutoplay();
    }

    function dragMove(e) {
      if (!isDragging) return;
      var currentPosition = getPositionX(e);
      var diff = currentPosition - startPos;
      var currentOffset = -(currentIndex * slideWidth) + diff;
      track.style.transform = 'translateX(' + currentOffset + 'px)';
    }

    function dragEnd(e) {
      if (!isDragging) return;
      isDragging = false;
      track.style.transition = 'transform 0.45s cubic-bezier(0.25, 1, 0.5, 1)';
      var movedBy = (getPositionX(e.type.includes('touch') ? e.changedTouches[0] : e) || startPos) - startPos;
      
      if (movedBy < -60) {
        nextSlide();
      } else if (movedBy > 60) {
        prevSlide();
      } else {
        goToSlide(currentIndex);
      }
      startAutoplay();
    }

    viewport.addEventListener('mousedown', dragStart);
    window.addEventListener('mousemove', dragMove);
    window.addEventListener('mouseup', dragEnd);

    viewport.addEventListener('touchstart', dragStart, { passive: true });
    viewport.addEventListener('touchmove', dragMove, { passive: true });
    viewport.addEventListener('touchend', dragEnd);

    // Autoplay logic
    function startAutoplay() {
      if (prefersReducedMotion || autoplayTimer) return;
      autoplayTimer = setInterval(function() {
        nextSlide();
      }, 5500);
    }

    function stopAutoplay() {
      if (autoplayTimer) {
        clearInterval(autoplayTimer);
        autoplayTimer = null;
      }
    }

    container.addEventListener('mouseenter', stopAutoplay);
    container.addEventListener('mouseleave', startAutoplay);

    window.addEventListener('resize', updateMetrics);
    updateMetrics();
    startAutoplay();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCarousel);
  } else {
    initCarousel();
  }
})();
