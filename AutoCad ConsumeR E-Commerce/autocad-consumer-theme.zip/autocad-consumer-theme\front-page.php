<?php
/**
 * AutoCad ConsumeR — Front Page Template
 * Complete Homepage Sections A through F
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

// Fetch Hero settings
$hero_tag   = get_theme_mod('cad_hero_tag', 'PRECISION ENGINEERING & CAD SOLUTIONS');
$hero_title = get_theme_mod('cad_hero_title', 'Supercharge Your Drafting Workflow with AutoCad ConsumeR');
$hero_desc  = get_theme_mod('cad_hero_desc', 'Premium AutoCAD templates, dynamic blocks, structural drafting libraries, and professional 2D conversion services tailored for architects, engineers, and CAD professionals.');
?>

<!-- ==========================================================================
     SECTION A — HERO BANNER
     ========================================================================== -->
<section class="cad-hero-section">
    <div class="cad-container">
        <div class="cad-hero-grid">
            <div class="cad-hero-content">
                <div class="cad-hero-badge">
                    <span class="cad-hero-badge-dot"></span>
                    <span><?php echo esc_html($hero_tag); ?></span>
                </div>
                <h1 class="cad-hero-headline">
                    <?php echo esc_html($hero_title); ?>
                </h1>
                <p class="cad-hero-desc">
                    <?php echo esc_html($hero_desc); ?>
                </p>
                <div class="cad-hero-ctas">
                    <a href="<?php echo esc_url(class_exists('WooCommerce') ? wc_get_page_permalink('shop') : '#cad-latest'); ?>" class="cad-btn cad-btn-primary">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="20" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                        <?php esc_html_e('Shop CAD Catalog', 'autocad-consumer'); ?>
                    </a>
                    <a href="#cad-services" class="cad-btn cad-btn-outline">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                            <polyline points="2 17 12 22 22 17"></polyline>
                            <polyline points="2 12 12 17 22 12"></polyline>
                        </svg>
                        <?php esc_html_e('Explore Design Services', 'autocad-consumer'); ?>
                    </a>
                </div>
                <div class="cad-hero-stats">
                    <div class="cad-stat-item">
                        <span class="cad-stat-val">100%</span>
                        <span class="cad-stat-label"><?php esc_html_e('Native DWG Files', 'autocad-consumer'); ?></span>
                    </div>
                    <div class="cad-stat-item">
                        <span class="cad-stat-val">24/7</span>
                        <span class="cad-stat-label"><?php esc_html_e('Instant Download', 'autocad-consumer'); ?></span>
                    </div>
                    <div class="cad-stat-item">
                        <span class="cad-stat-val">BDT (৳)</span>
                        <span class="cad-stat-label"><?php esc_html_e('bKash / Nagad / Rocket', 'autocad-consumer'); ?></span>
                    </div>
                </div>
            </div>

            <div class="cad-hero-visual">
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/cad-hero-mockup.svg'); ?>" alt="<?php esc_attr_e('AutoCAD Architectural Workspace', 'autocad-consumer'); ?>" class="cad-hero-img" width="600" height="440" />
                <div class="cad-hero-float-card">
                    <div class="cad-float-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                    </div>
                    <div class="cad-float-text">
                        <h4><?php esc_html_e('AutoCAD 2024 Verified', 'autocad-consumer'); ?></h4>
                        <p><?php esc_html_e('Standard Layers & Scales', 'autocad-consumer'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================================================
     SECTION B — FEATURED PRODUCT CAROUSEL WITH TEXT
     ========================================================================== -->
<section class="cad-featured-carousel-section" id="cad-featured">
    <div class="cad-container">
        <div class="cad-section-header">
            <span class="cad-section-tag"><?php esc_html_e('PREMIUM RESOURCES', 'autocad-consumer'); ?></span>
            <h2 class="cad-section-title"><?php esc_html_e('Explore Our Featured CAD Products', 'autocad-consumer'); ?></h2>
            <p class="cad-section-subtitle">
                <?php esc_html_e('Professional digital resources and drafting solutions designed to make your workflow faster and more efficient.', 'autocad-consumer'); ?>
            </p>
        </div>

        <div class="cad-carousel-container">
            <div class="cad-carousel-viewport">
                <div class="cad-carousel-track">
                    <?php
                    $featured_products = array();
                    if (class_exists('WooCommerce')) {
                        $featured_products = wc_get_products(array(
                            'status'   => 'publish',
                            'limit'    => 8,
                            'featured' => true,
                        ));

                        // Fallback to recent products if no product is explicitly marked featured yet
                        if (empty($featured_products)) {
                            $featured_products = wc_get_products(array(
                                'status' => 'publish',
                                'limit'  => 6,
                            ));
                        }
                    }

                    if (!empty($featured_products)) :
                        foreach ($featured_products as $product) :
                            $pid         = $product->get_id();
                            $title       = $product->get_name();
                            $permalink   = $product->get_permalink();
                            $short_desc  = wp_trim_words($product->get_short_description(), 12, '...');
                            $price_html  = $product->get_price_html();
                            $is_on_sale  = $product->is_on_sale();
                            $in_stock    = $product->is_in_stock();
                            $rating_count= $product->get_rating_count();
                            $average     = $product->get_average_rating();
                            $image_id    = $product->get_image_id();
                            $img_url     = $image_id ? wp_get_attachment_image_url($image_id, 'medium_large') : get_template_directory_uri() . '/assets/images/placeholders/cad-blocks.svg';
                            ?>
                            <div class="cad-carousel-slide">
                                <div class="cad-carousel-thumb-wrap">
                                    <a href="<?php echo esc_url($permalink); ?>">
                                        <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($title); ?>" class="cad-carousel-thumb" loading="lazy" />
                                    </a>
                                    <?php if ($is_on_sale) : ?>
                                        <span class="cad-carousel-badge-sale"><?php esc_html_e('SALE', 'autocad-consumer'); ?></span>
                                    <?php endif; ?>
                                    <span class="cad-carousel-badge-stock">
                                        <?php echo $in_stock ? esc_html__('IN STOCK', 'autocad-consumer') : esc_html__('OUT OF STOCK', 'autocad-consumer'); ?>
                                    </span>
                                </div>
                                <div class="cad-carousel-details">
                                    <?php if ($rating_count > 0) : ?>
                                        <div class="cad-carousel-rating">
                                            <span>★ <?php echo esc_html(number_format((float)$average, 1)); ?></span>
                                            <span class="cad-carousel-rating-count">(<?php echo esc_html($rating_count); ?>)</span>
                                        </div>
                                    <?php endif; ?>
                                    <h3 class="cad-carousel-prod-title">
                                        <a href="<?php echo esc_url($permalink); ?>"><?php echo esc_html($title); ?></a>
                                    </h3>
                                    <p class="cad-carousel-desc">
                                        <?php echo esc_html($short_desc ? $short_desc : __('Standard AutoCAD drawing package with fully organized layers and metric dimensions.', 'autocad-consumer')); ?>
                                    </p>
                                    <div class="cad-carousel-pricing">
                                        <span class="cad-carousel-price-curr"><?php echo wp_kses_post($price_html); ?></span>
                                    </div>
                                    <div class="cad-carousel-actions">
                                        <?php if ($product->is_type('variable')) : ?>
                                            <a href="<?php echo esc_url($permalink); ?>" class="cad-carousel-btn-cart">
                                                <?php esc_html_e('Select Options', 'autocad-consumer'); ?>
                                            </a>
                                        <?php else : ?>
                                            <a href="<?php echo esc_url($product->add_to_cart_url()); ?>" data-quantity="1" class="cad-carousel-btn-cart ajax_add_to_cart add_to_cart_button" data-product_id="<?php echo esc_attr($pid); ?>" data-product_sku="<?php echo esc_attr($product->get_sku()); ?>" aria-label="<?php echo esc_attr($product->add_to_cart_description()); ?>" rel="nofollow">
                                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <circle cx="9" cy="21" r="1"></circle>
                                                    <circle cx="20" cy="21" r="1"></circle>
                                                    <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                                                </svg>
                                                <?php esc_html_e('Add to Cart', 'autocad-consumer'); ?>
                                            </a>
                                        <?php endif; ?>
                                        <a href="<?php echo esc_url($permalink); ?>" class="cad-carousel-btn-details">
                                            <?php esc_html_e('Details', 'autocad-consumer'); ?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php
                        endforeach;
                    else :
                        // Dynamic Mockup items if WooCommerce is empty before sample import
                        $sample_items = array(
                            array('title' => 'Master Architectural CAD Block Bundle (1,500+ Blocks)', 'price' => '৳ 1,200', 'sale' => '৳ 899', 'img' => '/assets/images/placeholders/cad-blocks.svg', 'desc' => 'Extensive collection of 2D furniture, fixtures, doors, windows, and electrical symbols.'),
                            array('title' => 'Standard DWG/DXF Title Block & Sheet Templates (A0 to A4)', 'price' => '৳ 650', 'sale' => '৳ 499', 'img' => '/assets/images/placeholders/dwg-template.svg', 'desc' => 'Compliant with ISO & ANSI standards. Includes dynamic plotting CTB files.'),
                            array('title' => 'Residential Villa Multi-Story Architectural Drawing Set', 'price' => '৳ 2,500', 'sale' => '৳ 1,850', 'img' => '/assets/images/placeholders/architectural-plans.svg', 'desc' => 'Complete floor plans, sections, elevations, and roof drainage details.'),
                            array('title' => 'Reinforced Concrete Structural Detailing DWG Library', 'price' => '৳ 1,800', 'sale' => '৳ 1,350', 'img' => '/assets/images/placeholders/structural-steel.svg', 'desc' => 'Rebar detailing for columns, beams, footings, and structural steel connections.'),
                        );
                        foreach ($sample_items as $s_item) :
                        ?>
                            <div class="cad-carousel-slide">
                                <div class="cad-carousel-thumb-wrap">
                                    <img src="<?php echo esc_url(get_template_directory_uri() . $s_item['img']); ?>" alt="<?php echo esc_attr($s_item['title']); ?>" class="cad-carousel-thumb" />
                                    <span class="cad-carousel-badge-sale"><?php esc_html_e('SPECIAL OFFER', 'autocad-consumer'); ?></span>
                                    <span class="cad-carousel-badge-stock"><?php esc_html_e('IN STOCK', 'autocad-consumer'); ?></span>
                                </div>
                                <div class="cad-carousel-details">
                                    <h3 class="cad-carousel-prod-title"><a href="#cad-latest"><?php echo esc_html($s_item['title']); ?></a></h3>
                                    <p class="cad-carousel-desc"><?php echo esc_html($s_item['desc']); ?></p>
                                    <div class="cad-carousel-pricing">
                                        <span class="cad-carousel-price-curr"><?php echo esc_html($s_item['sale']); ?></span>
                                        <span class="cad-carousel-price-old"><?php echo esc_html($s_item['price']); ?></span>
                                    </div>
                                    <div class="cad-carousel-actions">
                                        <a href="#cad-latest" class="cad-carousel-btn-cart"><?php esc_html_e('Select Options', 'autocad-consumer'); ?></a>
                                        <a href="#cad-latest" class="cad-carousel-btn-details"><?php esc_html_e('Details', 'autocad-consumer'); ?></a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Controls (Dots and Arrows) -->
            <div class="cad-carousel-controls">
                <div class="cad-carousel-dots"></div>
                <div class="cad-carousel-nav-arrows">
                    <button type="button" class="cad-carousel-arrow cad-carousel-prev" aria-label="<?php esc_attr_e('Previous CAD Products', 'autocad-consumer'); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="15 18 9 12 15 6"></polyline>
                        </svg>
                    </button>
                    <button type="button" class="cad-carousel-arrow cad-carousel-next" aria-label="<?php esc_attr_e('Next CAD Products', 'autocad-consumer'); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="9 18 15 12 9 6"></polyline>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================================================
     SECTION C — PRODUCT CATEGORIES
     ========================================================================== -->
<section class="cad-categories-section" id="cad-categories">
    <div class="cad-container">
        <div class="cad-section-header">
            <span class="cad-section-tag"><?php esc_html_e('STRUCTURED TAXONOMY', 'autocad-consumer'); ?></span>
            <h2 class="cad-section-title"><?php esc_html_e('Browse by CAD Engineering Disciplines', 'autocad-consumer'); ?></h2>
            <p class="cad-section-subtitle">
                <?php esc_html_e('Explore meticulously organized AutoCAD assets, standard templates, and specialized engineering toolkits.', 'autocad-consumer'); ?>
            </p>
        </div>

        <div class="cad-categories-grid">
            <?php
            $product_categories = get_terms(array(
                'taxonomy'   => 'product_cat',
                'hide_empty' => false,
            ));

            if (!empty($product_categories) && !is_wp_error($product_categories)) :
                foreach ($product_categories as $cat) :
                    $cat_link  = get_term_link($cat);
                    $thumb_id  = get_term_meta($cat->term_id, 'thumbnail_id', true);
                    $cat_count = $cat->count;
                    ?>
                    <a href="<?php echo esc_url($cat_link); ?>" class="cad-cat-card">
                        <div class="cad-cat-header">
                            <div class="cad-cat-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                                    <polyline points="2 17 12 22 22 17"></polyline>
                                    <polyline points="2 12 12 17 22 12"></polyline>
                                </svg>
                            </div>
                            <span class="cad-cat-count"><?php echo esc_html($cat_count); ?> <?php esc_html_e('Files', 'autocad-consumer'); ?></span>
                        </div>
                        <h3 class="cad-cat-title"><?php echo esc_html($cat->name); ?></h3>
                        <p class="cad-cat-desc"><?php echo esc_html($cat->description ? $cat->description : __('High-precision native AutoCAD files with standardized layers, scales, and line weights.', 'autocad-consumer')); ?></p>
                        <div class="cad-cat-action">
                            <span><?php esc_html_e('Open Category', 'autocad-consumer'); ?></span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </div>
                    </a>
                <?php
                endforeach;
            else :
                // Default discipline cards
                $default_cats = array(
                    array('name' => 'CAD Blocks & Symbols', 'desc' => '1,500+ Furniture, electrical, plumbing, sanitary, and mechanical 2D blocks.', 'count' => '45+ Packs'),
                    array('name' => 'DWG/DXF Templates', 'desc' => 'Standardized drawing sheets, title blocks (A0 to A4), and CTB plot styles.', 'count' => '18+ Sets'),
                    array('name' => 'Architectural Drafting', 'desc' => 'Full residential & commercial drawings: floor plans, elevations, sections.', 'count' => '32+ Plans'),
                    array('name' => 'Structural Drawing Resources', 'desc' => 'RC column/beam rebar details, foundation layouts, and steel connections.', 'count' => '24+ Sets'),
                    array('name' => 'BOQ & Estimation Tools', 'desc' => 'Dynamic Excel spreadsheets with automated rate analysis for Bangladesh.', 'count' => '12+ Tools'),
                    array('name' => 'Custom CAD Design Services', 'desc' => 'Turnkey 2D drafting, PDF-to-CAD conversion, redline cleanups, and plotting.', 'count' => 'Services'),
                );
                foreach ($default_cats as $dc) :
                ?>
                    <a href="#cad-latest" class="cad-cat-card">
                        <div class="cad-cat-header">
                            <div class="cad-cat-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                                    <polyline points="2 17 12 22 22 17"></polyline>
                                    <polyline points="2 12 12 17 22 12"></polyline>
                                </svg>
                            </div>
                            <span class="cad-cat-count"><?php echo esc_html($dc['count']); ?></span>
                        </div>
                        <h3 class="cad-cat-title"><?php echo esc_html($dc['name']); ?></h3>
                        <p class="cad-cat-desc"><?php echo esc_html($dc['desc']); ?></p>
                        <div class="cad-cat-action">
                            <span><?php esc_html_e('Explore Files', 'autocad-consumer'); ?></span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ==========================================================================
     SECTION D — LATEST PRODUCTS
     ========================================================================== -->
<section class="cad-latest-section" id="cad-latest">
    <div class="cad-container">
        <div class="cad-section-header">
            <span class="cad-section-tag"><?php esc_html_e('NEW RELEASES', 'autocad-consumer'); ?></span>
            <h2 class="cad-section-title"><?php esc_html_e('Latest AutoCAD Products & Templates', 'autocad-consumer'); ?></h2>
            <p class="cad-section-subtitle">
                <?php esc_html_e('Updated regularly with verified engineering accuracy and full compatibility with modern CAD platforms.', 'autocad-consumer'); ?>
            </p>
        </div>

        <!-- Filter Bar -->
        <div class="cad-filter-bar">
            <div class="cad-filter-tabs">
                <button type="button" class="cad-filter-tab active" data-cat-slug="all"><?php esc_html_e('All Resources', 'autocad-consumer'); ?></button>
                <button type="button" class="cad-filter-tab" data-cat-slug="cad-blocks"><?php esc_html_e('Blocks & Symbols', 'autocad-consumer'); ?></button>
                <button type="button" class="cad-filter-tab" data-cat-slug="templates"><?php esc_html_e('Templates', 'autocad-consumer'); ?></button>
                <button type="button" class="cad-filter-tab" data-cat-slug="architectural"><?php esc_html_e('Architectural', 'autocad-consumer'); ?></button>
                <button type="button" class="cad-filter-tab" data-cat-slug="structural"><?php esc_html_e('Structural', 'autocad-consumer'); ?></button>
            </div>
            <div class="cad-sort-wrapper">
                <select class="cad-sort-select" onchange="location = this.value;">
                    <option value="<?php echo esc_url(add_query_arg('orderby', 'date')); ?>"><?php esc_html_e('Sort by: Latest Releases', 'autocad-consumer'); ?></option>
                    <option value="<?php echo esc_url(add_query_arg('orderby', 'price')); ?>"><?php esc_html_e('Sort by: Price (Low to High)', 'autocad-consumer'); ?></option>
                    <option value="<?php echo esc_url(add_query_arg('orderby', 'price-desc')); ?>"><?php esc_html_e('Sort by: Price (High to Low)', 'autocad-consumer'); ?></option>
                    <option value="<?php echo esc_url(add_query_arg('orderby', 'popularity')); ?>"><?php esc_html_e('Sort by: Popularity', 'autocad-consumer'); ?></option>
                </select>
            </div>
        </div>

        <div class="cad-products-grid">
            <?php
            $latest_prods = array();
            if (class_exists('WooCommerce')) {
                $latest_prods = wc_get_products(array(
                    'status' => 'publish',
                    'limit'  => 8,
                    'orderby'=> 'date',
                    'order'  => 'DESC',
                ));
            }

            if (!empty($latest_prods)) :
                foreach ($latest_prods as $prod) :
                    $pid        = $prod->get_id();
                    $title      = $prod->get_name();
                    $permalink  = $prod->get_permalink();
                    $price_html = $prod->get_price_html();
                    $in_stock   = $prod->is_in_stock();
                    $is_sale    = $prod->is_on_sale();
                    $terms      = get_the_terms($pid, 'product_cat');
                    $cat_slugs  = '';
                    $cat_name   = 'CAD Product';
                    if (!empty($terms) && !is_wp_error($terms)) {
                        $cat_name  = $terms[0]->name;
                        $cat_slugs = implode(' ', wp_list_pluck($terms, 'slug'));
                    }
                    $image_id = $prod->get_image_id();
                    $img_url  = $image_id ? wp_get_attachment_image_url($image_id, 'medium_large') : get_template_directory_uri() . '/assets/images/placeholders/cad-blocks.svg';
                    ?>
                    <div class="cad-prod-card" data-cats="<?php echo esc_attr($cat_slugs); ?>">
                        <div class="cad-prod-thumb-wrap">
                            <a href="<?php echo esc_url($permalink); ?>">
                                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($title); ?>" class="cad-prod-thumb" loading="lazy" />
                            </a>
                            <?php if ($is_sale) : ?>
                                <span class="cad-badge-sale"><?php esc_html_e('SALE', 'autocad-consumer'); ?></span>
                            <?php endif; ?>
                            <span class="cad-badge-stock"><?php echo $in_stock ? esc_html__('IN STOCK', 'autocad-consumer') : esc_html__('OUT OF STOCK', 'autocad-consumer'); ?></span>
                        </div>
                        <div class="cad-prod-details">
                            <span class="cad-prod-cat"><?php echo esc_html($cat_name); ?></span>
                            <h3 class="cad-prod-title">
                                <a href="<?php echo esc_url($permalink); ?>"><?php echo esc_html($title); ?></a>
                            </h3>
                            <p class="cad-prod-desc">
                                <?php echo esc_html(wp_trim_words($prod->get_short_description(), 10, '...')); ?>
                            </p>
                            <div class="cad-prod-meta">
                                <div class="cad-price-wrap">
                                    <span class="cad-regular-price"><?php echo wp_kses_post($price_html); ?></span>
                                </div>
                            </div>
                            <div class="cad-card-actions">
                                <?php if ($prod->is_type('variable')) : ?>
                                    <a href="<?php echo esc_url($permalink); ?>" class="cad-btn-card-cart">
                                        <?php esc_html_e('Select Options', 'autocad-consumer'); ?>
                                    </a>
                                <?php else : ?>
                                    <a href="<?php echo esc_url($prod->add_to_cart_url()); ?>" data-quantity="1" class="cad-btn-card-cart ajax_add_to_cart add_to_cart_button" data-product_id="<?php echo esc_attr($pid); ?>" data-product_sku="<?php echo esc_attr($prod->get_sku()); ?>" aria-label="<?php echo esc_attr($prod->add_to_cart_description()); ?>" rel="nofollow">
                                        <?php esc_html_e('Add to Cart', 'autocad-consumer'); ?>
                                    </a>
                                <?php endif; ?>
                                <a href="<?php echo esc_url($permalink); ?>" class="cad-btn-card-details">
                                    <?php esc_html_e('Details', 'autocad-consumer'); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php
                endforeach;
            else :
                // Demo fallback cards
                $demo_latest = array(
                    array('title' => 'Master CAD Furniture Blocks', 'cat' => 'cad-blocks', 'cat_name' => 'CAD Blocks', 'price' => '৳ 399', 'img' => '/assets/images/placeholders/cad-blocks.svg'),
                    array('title' => 'Standard DWG Sheet Template Bundle', 'cat' => 'templates', 'cat_name' => 'Templates', 'price' => '৳ 499', 'img' => '/assets/images/placeholders/dwg-template.svg'),
                    array('title' => 'Residential Architectural Villa Plans', 'cat' => 'architectural', 'cat_name' => 'Architectural', 'price' => '৳ 1,850', 'img' => '/assets/images/placeholders/architectural-plans.svg'),
                    array('title' => 'Structural Detailing & Rebar Suite', 'cat' => 'structural', 'cat_name' => 'Structural', 'price' => '৳ 1,350', 'img' => '/assets/images/placeholders/structural-steel.svg'),
                    array('title' => 'Building Construction BOQ Estimator', 'cat' => 'templates', 'cat_name' => 'BOQ Tools', 'price' => '৳ 750', 'img' => '/assets/images/placeholders/boq-estimator.svg'),
                    array('title' => 'Professional PDF to CAD Drafting Service', 'cat' => 'services', 'cat_name' => 'Drafting Service', 'price' => '৳ 1,500', 'img' => '/assets/images/placeholders/drafting-service.svg'),
                );
                foreach ($demo_latest as $dl) :
                ?>
                    <div class="cad-prod-card" data-cats="<?php echo esc_attr($dl['cat']); ?>">
                        <div class="cad-prod-thumb-wrap">
                            <img src="<?php echo esc_url(get_template_directory_uri() . $dl['img']); ?>" alt="<?php echo esc_attr($dl['title']); ?>" class="cad-prod-thumb" />
                            <span class="cad-badge-stock"><?php esc_html_e('IN STOCK', 'autocad-consumer'); ?></span>
                        </div>
                        <div class="cad-prod-details">
                            <span class="cad-prod-cat"><?php echo esc_html($dl['cat_name']); ?></span>
                            <h3 class="cad-prod-title"><a href="#cad-services"><?php echo esc_html($dl['title']); ?></a></h3>
                            <p class="cad-prod-desc"><?php esc_html_e('Fully layered, standard CAD drawing package with clean linework and metric dimensions.', 'autocad-consumer'); ?></p>
                            <div class="cad-prod-meta">
                                <div class="cad-price-wrap">
                                    <span class="cad-regular-price"><?php echo esc_html($dl['price']); ?></span>
                                </div>
                            </div>
                            <div class="cad-card-actions">
                                <a href="#cad-services" class="cad-btn-card-cart"><?php esc_html_e('View Details', 'autocad-consumer'); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ==========================================================================
     SECTION E — WHY CHOOSE US
     ========================================================================== -->
<section class="cad-why-section" id="cad-why">
    <div class="cad-container">
        <div class="cad-section-header">
            <span class="cad-section-tag"><?php esc_html_e('ENGINEERING INTEGRITY', 'autocad-consumer'); ?></span>
            <h2 class="cad-section-title"><?php esc_html_e('Why AutoCAD Professionals Choose Us', 'autocad-consumer'); ?></h2>
            <p class="cad-section-subtitle">
                <?php esc_html_e('Engineered specifically for architects, engineers, CAD draftsmen, and construction contractors.', 'autocad-consumer'); ?>
            </p>
        </div>

        <div class="cad-why-grid">
            <div class="cad-why-card">
                <div class="cad-why-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                        <polyline points="2 17 12 22 22 17"></polyline>
                        <polyline points="2 12 12 17 22 12"></polyline>
                    </svg>
                </div>
                <h3 class="cad-why-title"><?php esc_html_e('100% Native CAD Quality', 'autocad-consumer'); ?></h3>
                <p class="cad-why-desc"><?php esc_html_e('Clean geometries, standardized layers, zero purge errors, and scale-accurate linework matching international standards.', 'autocad-consumer'); ?></p>
            </div>

            <div class="cad-why-card">
                <div class="cad-why-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7 10 12 15 17 10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                </div>
                <h3 class="cad-why-title"><?php esc_html_e('Instant Digital Access', 'autocad-consumer'); ?></h3>
                <p class="cad-why-desc"><?php esc_html_e('Download your digital DWG, DXF, and PDF bundles immediately upon order verification directly from your account.', 'autocad-consumer'); ?></p>
            </div>

            <div class="cad-why-card">
                <div class="cad-why-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                    </svg>
                </div>
                <h3 class="cad-why-title"><?php esc_html_e('Verified BDT Mobile Checkout', 'autocad-consumer'); ?></h3>
                <p class="cad-why-desc"><?php esc_html_e('Pay comfortably in BDT using bKash, Nagad, Rocket Send Money, or Cash on Delivery with transparent order tracking.', 'autocad-consumer'); ?></p>
            </div>

            <div class="cad-why-card">
                <div class="cad-why-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                    </svg>
                </div>
                <h3 class="cad-why-title"><?php esc_html_e('Custom Drafting Backed', 'autocad-consumer'); ?></h3>
                <p class="cad-why-desc"><?php esc_html_e('Need custom modifications? Our experienced CAD operators provide rapid turnaround 2D drafting and redline revisions.', 'autocad-consumer'); ?></p>
            </div>
        </div>
    </div>
</section>

<!-- ==========================================================================
     SECTION F — DESIGN SERVICES & QUOTE
     ========================================================================== -->
<section class="cad-services-section" id="cad-services">
    <div class="cad-container">
        <div class="cad-section-header">
            <span class="cad-section-tag"><?php esc_html_e('DRAFTING BUREAU', 'autocad-consumer'); ?></span>
            <h2 class="cad-section-title"><?php esc_html_e('Professional AutoCAD Drafting Services', 'autocad-consumer'); ?></h2>
            <p class="cad-section-subtitle">
                <?php esc_html_e('Dedicated technical services for architectural, structural, and civil engineering drawings.', 'autocad-consumer'); ?>
            </p>
        </div>

        <div class="cad-services-grid">
            <!-- Service 1 -->
            <div class="cad-service-card">
                <div class="cad-service-header">
                    <span class="cad-service-badge"><?php esc_html_e('CORE SERVICE', 'autocad-consumer'); ?></span>
                    <span class="cad-service-price"><?php esc_html_e('From ৳ 1,500 / sheet', 'autocad-consumer'); ?></span>
                </div>
                <h3 class="cad-service-title"><?php esc_html_e('2D CAD Drafting', 'autocad-consumer'); ?></h3>
                <p class="cad-service-desc"><?php esc_html_e('Precision architectural floor plans, building elevations, sectional cuts, and structural layouts drawn to scale in standard layers.', 'autocad-consumer'); ?></p>
                <ul class="cad-service-specs">
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('Turnaround: 24 to 48 Hours', 'autocad-consumer'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('Includes: 2 Iterative Revisions', 'autocad-consumer'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('Deliverable: .DWG + Print-ready .PDF', 'autocad-consumer'); ?></li>
                </ul>
                <button type="button" class="cad-btn cad-btn-secondary cad-open-quote-modal" data-service-title="2D CAD Drafting">
                    <?php esc_html_e('Request Quote', 'autocad-consumer'); ?>
                </button>
            </div>

            <!-- Service 2 -->
            <div class="cad-service-card">
                <div class="cad-service-header">
                    <span class="cad-service-badge"><?php esc_html_e('CONVERSION', 'autocad-consumer'); ?></span>
                    <span class="cad-service-price"><?php esc_html_e('From ৳ 800 / sheet', 'autocad-consumer'); ?></span>
                </div>
                <h3 class="cad-service-title"><?php esc_html_e('PDF-to-CAD Vectorization', 'autocad-consumer'); ?></h3>
                <p class="cad-service-desc"><?php esc_html_e('Manual re-vectorization of scanned blueprints, paper blueprints, and raster PDFs into fully editable AutoCAD vector drawings with proper scales.', 'autocad-consumer'); ?></p>
                <ul class="cad-service-specs">
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('Turnaround: 12 to 24 Hours', 'autocad-consumer'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('100% Dimension Precision Guaranteed', 'autocad-consumer'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('Organized AIA / ISO CAD Layers', 'autocad-consumer'); ?></li>
                </ul>
                <button type="button" class="cad-btn cad-btn-secondary cad-open-quote-modal" data-service-title="PDF to CAD Conversion">
                    <?php esc_html_e('Request Quote', 'autocad-consumer'); ?>
                </button>
            </div>

            <!-- Service 3 -->
            <div class="cad-service-card">
                <div class="cad-service-header">
                    <span class="cad-service-badge"><?php esc_html_e('OPTIMIZATION', 'autocad-consumer'); ?></span>
                    <span class="cad-service-price"><?php esc_html_e('From ৳ 500 / file', 'autocad-consumer'); ?></span>
                </div>
                <h3 class="cad-service-title"><?php esc_html_e('Drawing Cleanup & Sheet Setup', 'autocad-consumer'); ?></h3>
                <p class="cad-service-desc"><?php esc_html_e('Audit, purge unreferenced blocks, fix scale mismatch, set up layout viewports, and calibrate monochrome/color CTB plot styles for printing.', 'autocad-consumer'); ?></p>
                <ul class="cad-service-specs">
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('Turnaround: Same Day Service', 'autocad-consumer'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('Reduces File Size up to 70%', 'autocad-consumer'); ?></li>
                    <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg> <?php esc_html_e('Ready for A0 / A1 / A3 Plotting', 'autocad-consumer'); ?></li>
                </ul>
                <button type="button" class="cad-btn cad-btn-secondary cad-open-quote-modal" data-service-title="Drawing Cleanup & Sheet Setup">
                    <?php esc_html_e('Request Quote', 'autocad-consumer'); ?>
                </button>
            </div>
        </div>

        <!-- Banner for Custom Quotes -->
        <div class="cad-quote-banner">
            <div class="cad-quote-info">
                <h3><?php esc_html_e('Have a Complex Engineering Drawing Request?', 'autocad-consumer'); ?></h3>
                <p><?php esc_html_e('Upload your project sketches or existing DWG files. Our senior CAD technicians will review your project and return a custom quotation within 4 hours.', 'autocad-consumer'); ?></p>
                <div class="cad-quote-disclaimer">
                    <?php esc_html_e('* All design consultations adhere to strict CAD drawing best practices and non-disclosure privacy.', 'autocad-consumer'); ?>
                </div>
            </div>
            <button type="button" class="cad-btn cad-btn-primary cad-open-quote-modal" data-service-title="Custom Complex Project Quote">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="22" y1="2" x2="11" y2="13"></line>
                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                </svg>
                <?php esc_html_e('Submit Project For Quote', 'autocad-consumer'); ?>
            </button>
        </div>
    </div>
</section>

<?php
get_footer();
