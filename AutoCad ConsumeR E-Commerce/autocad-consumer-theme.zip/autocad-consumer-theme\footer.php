<?php
/**
 * AutoCad ConsumeR — Footer Template
 * Contains Section G specifications, Quote Request Modal, and engineering disclaimers.
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
</main><!-- #primary -->

<footer id="colophon" class="cad-footer">
    <div class="cad-container">
        <!-- Professional Engineering Disclaimer -->
        <div class="cad-disclaimer-box">
            <strong><?php esc_html_e('TECHNICAL & REGULATORY NOTICE:', 'autocad-consumer'); ?></strong>
            <?php esc_html_e('CAD files, templates, and 2D drafting outputs provided by AutoCad ConsumeR are design resources and drafting aids. They must not be represented as construction-ready or structurally certified unless independent review, calculation, and official seal have been performed by a licensed professional engineer (PE) or registered architect appropriate for your project jurisdiction.', 'autocad-consumer'); ?>
        </div>

        <div class="cad-footer-grid">
            <!-- Brand Column -->
            <div class="cad-footer-brand">
                <?php autocad_consumer_logo(); ?>
                <p>
                    <?php esc_html_e('AutoCad ConsumeR is Bangladesh\'s premier digital engineering marketplace. We provide production-grade AutoCAD drawings, dynamic block suites, structural details, and professional drafting conversion services for AEC industry professionals.', 'autocad-consumer'); ?>
                </p>
                <div class="cad-header-socials" style="margin-top:20px;">
                    <?php autocad_consumer_social_links(); ?>
                </div>
            </div>

            <!-- Quick Shop Links -->
            <div class="cad-footer-col">
                <h4><?php esc_html_e('CAD Resources', 'autocad-consumer'); ?></h4>
                <ul class="cad-footer-links">
                    <li><a href="<?php echo esc_url(class_exists('WooCommerce') ? wc_get_page_permalink('shop') : '#'); ?>"><?php esc_html_e('All Products', 'autocad-consumer'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/#cad-categories')); ?>"><?php esc_html_e('CAD Blocks & Symbols', 'autocad-consumer'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/#cad-categories')); ?>"><?php esc_html_e('DWG/DXF Templates', 'autocad-consumer'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/#cad-categories')); ?>"><?php esc_html_e('Structural Drawing Sets', 'autocad-consumer'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/#cad-categories')); ?>"><?php esc_html_e('BOQ & Estimation Tools', 'autocad-consumer'); ?></a></li>
                </ul>
            </div>

            <!-- Store & Legal Policies -->
            <div class="cad-footer-col">
                <h4><?php esc_html_e('Store Policies', 'autocad-consumer'); ?></h4>
                <ul class="cad-footer-links">
                    <li><a href="<?php echo esc_url(get_privacy_policy_url() ? get_privacy_policy_url() : home_url('/privacy-policy')); ?>"><?php esc_html_e('Privacy Policy', 'autocad-consumer'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/terms-and-conditions')); ?>"><?php esc_html_e('Terms & Conditions', 'autocad-consumer'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/refund-cancellation-policy')); ?>"><?php esc_html_e('Refund & Cancellation', 'autocad-consumer'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/digital-product-delivery')); ?>"><?php esc_html_e('Digital Delivery Info', 'autocad-consumer'); ?></a></li>
                    <li><a href="<?php echo esc_url(class_exists('WooCommerce') ? wc_get_page_permalink('myaccount') : '#'); ?>"><?php esc_html_e('Customer Account & Downloads', 'autocad-consumer'); ?></a></li>
                </ul>
            </div>

            <!-- Admin-Editable Business Contact Column -->
            <div class="cad-footer-col">
                <h4><?php esc_html_e('Engineering Office', 'autocad-consumer'); ?></h4>
                <ul class="cad-contact-list">
                    <li>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                        <span><?php echo nl2br(esc_html(get_theme_mod('cad_address', 'Engineering Tower, Level 4, Panthapath, Dhaka-1205, Bangladesh'))); ?></span>
                    </li>
                    <li>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        <span><?php echo esc_html(get_theme_mod('cad_phone', '+880 1712-345678')); ?></span>
                    </li>
                    <li>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                            <polyline points="22,6 12,13 2,6"></polyline>
                        </svg>
                        <span><?php echo esc_html(get_theme_mod('cad_email', 'support@autocadconsumer.com')); ?></span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Bottom Copyright -->
    <div class="cad-footer-bottom">
        <div class="cad-container">
            <p style="margin:0; font-size:0.8125rem;">
                &copy; <?php echo esc_html(gmdate('Y')); ?> <strong>AutoCad ConsumeR</strong>. <?php esc_html_e('All rights reserved. Designed for CAD & Engineering Productivity.', 'autocad-consumer'); ?>
            </p>
            <div style="font-size:0.8125rem; color:var(--cad-text-dim);">
                <span><?php esc_html_e('Accepted BDT Mobile Payments: bKash | Nagad | Rocket | COD', 'autocad-consumer'); ?></span>
            </div>
        </div>
    </div>
</footer>

<!-- Quote Request Modal (Section F) -->
<div id="cadQuoteModal" class="cad-modal-backdrop" aria-hidden="true">
    <div class="cad-modal-window" role="dialog" aria-labelledby="cadQuoteModalHeading">
        <div class="cad-modal-header">
            <h3 id="cadQuoteModalHeading">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polygon points="12 2 2 7 12 12 22 7 12 2"></polygon>
                    <polyline points="2 17 12 22 22 17"></polyline>
                    <polyline points="2 12 12 17 22 12"></polyline>
                </svg>
                <?php esc_html_e('Request Custom CAD Drafting Quote', 'autocad-consumer'); ?>
            </h3>
            <button type="button" id="cadQuoteModalClose" class="cad-modal-close" aria-label="<?php esc_attr_e('Close Quote Modal', 'autocad-consumer'); ?>">&times;</button>
        </div>
        <div class="cad-modal-body">
            <p style="font-size:0.875rem; color:var(--cad-text-dim); margin-bottom:20px;">
                <?php esc_html_e('Fill out your project specifications. You can attach a PDF, hand sketch, or existing DWG file for accurate quotation.', 'autocad-consumer'); ?>
            </p>
            <form id="cadQuoteForm" enctype="multipart/form-data">
                <!-- Anti-bot honeypot -->
                <input type="text" name="cad_website_hp" class="cad-honeypot" tabindex="-1" autocomplete="off" />

                <div class="cad-form-row">
                    <div class="cad-form-group">
                        <label for="cadQuoteName"><?php esc_html_e('Your Full Name *', 'autocad-consumer'); ?></label>
                        <input type="text" id="cadQuoteName" name="quote_name" class="cad-form-control" required placeholder="Engr. / Architect Name" />
                    </div>
                    <div class="cad-form-group">
                        <label for="cadQuotePhone"><?php esc_html_e('Phone Number (01XXXXXXXXX) *', 'autocad-consumer'); ?></label>
                        <input type="tel" id="cadQuotePhone" name="quote_phone" class="cad-form-control" required placeholder="01712345678" pattern="[0-9+ ]{10,15}" />
                    </div>
                </div>

                <div class="cad-form-row">
                    <div class="cad-form-group">
                        <label for="cadQuoteEmail"><?php esc_html_e('Email Address *', 'autocad-consumer'); ?></label>
                        <input type="email" id="cadQuoteEmail" name="quote_email" class="cad-form-control" required placeholder="engineer@domain.com" />
                    </div>
                    <div class="cad-form-group">
                        <label for="cadQuoteService"><?php esc_html_e('Service Required *', 'autocad-consumer'); ?></label>
                        <select id="cadQuoteService" name="quote_service" class="cad-form-control">
                            <option value="2D CAD Drafting"><?php esc_html_e('2D CAD Drafting (Architectural / Structural)', 'autocad-consumer'); ?></option>
                            <option value="PDF to CAD Conversion"><?php esc_html_e('PDF to Layered DWG Conversion', 'autocad-consumer'); ?></option>
                            <option value="Drawing Cleanup & Optimization"><?php esc_html_e('Drawing Cleanup & Layer Standardization', 'autocad-consumer'); ?></option>
                            <option value="Drawing-Sheet & Plotting Setup"><?php esc_html_e('Title Block & Plot Style (CTB) Setup', 'autocad-consumer'); ?></option>
                            <option value="Custom Project Drafting"><?php esc_html_e('Custom Drawing Request', 'autocad-consumer'); ?></option>
                        </select>
                    </div>
                </div>

                <div class="cad-form-group">
                    <label for="cadQuoteScope"><?php esc_html_e('Project Scope & Instructions *', 'autocad-consumer'); ?></label>
                    <textarea id="cadQuoteScope" name="quote_scope" class="cad-form-control" rows="4" required placeholder="<?php esc_attr_e('Describe drawing scale, number of sheets, deadline, or special layer requirements...', 'autocad-consumer'); ?>"></textarea>
                </div>

                <div class="cad-form-group">
                    <label for="cadQuoteFile"><?php esc_html_e('Attach Reference File (PDF, DWG, DXF, PNG, JPG, or ZIP up to 25MB)', 'autocad-consumer'); ?></label>
                    <input type="file" id="cadQuoteFile" name="quote_file" class="cad-form-control" accept=".pdf,.dwg,.dxf,.zip,.png,.jpg,.jpeg" />
                </div>

                <div class="cad-quote-response-msg" style="display:none;"></div>

                <div style="display:flex; justify-content:flex-end; gap:12px; margin-top:20px;">
                    <button type="button" id="cadQuoteModalCancel" class="cad-btn cad-btn-dark"><?php esc_html_e('Cancel', 'autocad-consumer'); ?></button>
                    <button type="submit" class="cad-btn cad-btn-primary"><?php esc_html_e('Submit Quote Request', 'autocad-consumer'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
