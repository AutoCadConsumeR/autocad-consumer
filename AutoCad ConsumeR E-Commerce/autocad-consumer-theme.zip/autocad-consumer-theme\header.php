<?php
/**
 * AutoCad ConsumeR — Header Template
 *
 * Exact Desktop Layout (Left to Right):
 * 1. AutoCad ConsumeR logo
 * 2. Product search input beside the logo
 * 3. Login and registration option
 * 4. Social media icons with admin-editable links
 * 5. Shopping cart button with live cart-count badge
 * 6. Cart side drawer that slides in from the right
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Top Engineering Announcement Bar -->
<div class="cad-topbar">
    <div class="cad-container">
        <div class="cad-topbar-left">
            <span class="cad-topbar-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                </svg>
                <span><?php echo esc_html(get_theme_mod('cad_phone', '+880 1712-345678')); ?></span>
            </span>
            <span class="cad-topbar-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
                <span><?php esc_html_e('24/7 Instant Digital CAD File Downloads', 'autocad-consumer'); ?></span>
            </span>
        </div>
        <div class="cad-topbar-right">
            <span class="cad-badge-tag"><?php esc_html_e('CURRENCY: BDT (৳)', 'autocad-consumer'); ?></span>
            <a href="#cad-services" style="color:var(--cad-technical-cyan); font-weight:600;">
                <?php esc_html_e('Custom CAD Drafting Service', 'autocad-consumer'); ?> →
            </a>
        </div>
    </div>
</div>

<!-- Main Site Header -->
<header id="masthead" class="cad-header">
    <div class="cad-container">
        <div class="cad-header-inner">
            <!-- 1. AutoCad ConsumeR Logo (Top-Left) -->
            <?php autocad_consumer_logo(); ?>

            <!-- 2. Product Search Input Beside Logo -->
            <div class="cad-header-search">
                <form role="search" method="get" class="cad-search-form" action="<?php echo esc_url(home_url('/')); ?>">
                    <?php if (class_exists('WooCommerce')) : ?>
                        <?php
                        $categories = get_terms(array(
                            'taxonomy'   => 'product_cat',
                            'hide_empty' => false,
                        ));
                        if (!empty($categories) && !is_wp_error($categories)) :
                        ?>
                            <select name="product_cat" class="cad-search-cat-select" aria-label="<?php esc_attr_e('Select category', 'autocad-consumer'); ?>">
                                <option value=""><?php esc_html_e('All CAD Categories', 'autocad-consumer'); ?></option>
                                <?php foreach ($categories as $cat) : ?>
                                    <option value="<?php echo esc_attr($cat->slug); ?>" <?php selected(get_query_var('product_cat'), $cat->slug); ?>>
                                        <?php echo esc_html($cat->name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                        <input type="hidden" name="post_type" value="product" />
                    <?php endif; ?>
                    <input type="search" class="cad-search-input" placeholder="<?php esc_attr_e('Search DWG blocks, templates, plans...', 'autocad-consumer'); ?>" value="<?php echo get_search_query(); ?>" name="s" required />
                    <button type="submit" class="cad-search-submit" aria-label="<?php esc_attr_e('Search CAD Catalog', 'autocad-consumer'); ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="8"></circle>
                            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                        </svg>
                    </button>
                </form>
            </div>

            <!-- 3. Login and Registration Option -->
            <div class="cad-header-account">
                <?php if (is_user_logged_in()) : ?>
                    <?php $current_user = wp_get_current_user(); ?>
                    <a href="<?php echo esc_url(class_exists('WooCommerce') ? wc_get_page_permalink('myaccount') : admin_url('profile.php')); ?>" class="cad-account-btn">
                        <svg class="cad-account-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                            <circle cx="12" cy="7" r="4"></circle>
                        </svg>
                        <div class="cad-account-text">
                            <span class="cad-account-greeting"><?php esc_html_e('Hello,', 'autocad-consumer'); ?></span>
                            <span class="cad-account-label"><?php echo esc_html($current_user->display_name); ?></span>
                        </div>
                    </a>
                <?php else : ?>
                    <a href="<?php echo esc_url(class_exists('WooCommerce') ? wc_get_page_permalink('myaccount') : wp_login_url()); ?>" class="cad-account-btn">
                        <svg class="cad-account-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                            <polyline points="10 17 15 12 10 7"></polyline>
                            <line x1="15" y1="12" x2="3" y2="12"></line>
                        </svg>
                        <div class="cad-account-text">
                            <span class="cad-account-greeting"><?php esc_html_e('Sign In / Register', 'autocad-consumer'); ?></span>
                            <span class="cad-account-label"><?php esc_html_e('My Account', 'autocad-consumer'); ?></span>
                        </div>
                    </a>
                <?php endif; ?>
            </div>

            <!-- 4. Social Media Icons with Admin-Editable Links -->
            <div class="cad-header-socials">
                <?php autocad_consumer_social_links(); ?>
            </div>

            <!-- 5. Shopping Cart Button with Live Cart-Count Badge -->
            <div class="cad-header-cart">
                <?php
                $cart_count = 0;
                $cart_total = '৳0.00';
                if (class_exists('WooCommerce') && WC()->cart) {
                    $cart_count = WC()->cart->get_cart_contents_count();
                    $cart_total = WC()->cart->get_cart_total();
                }
                ?>
                <button type="button" class="cad-cart-trigger" aria-label="<?php esc_attr_e('Open Shopping Cart Drawer', 'autocad-consumer'); ?>">
                    <div class="cad-cart-icon-wrap">
                        <svg class="cad-cart-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="20" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                        <span class="cad-cart-badge"><?php echo esc_html($cart_count); ?></span>
                    </div>
                    <span class="cad-cart-total-text"><?php echo wp_kses_post($cart_total); ?></span>
                </button>
            </div>

            <!-- Mobile Hamburger Toggle -->
            <button type="button" id="cadMobileToggle" class="cad-mobile-toggle" aria-label="<?php esc_attr_e('Toggle navigation', 'autocad-consumer'); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="3" y1="12" x2="21" y2="12"></line>
                    <line x1="3" y1="6" x2="21" y2="6"></line>
                    <line x1="3" y1="18" x2="21" y2="18"></line>
                </svg>
            </button>
        </div>
    </div>
</header>

<!-- Secondary CAD Navigation Bar -->
<nav class="cad-navbar" aria-label="<?php esc_attr_e('Catalog Navigation', 'autocad-consumer'); ?>">
    <div class="cad-container">
        <?php
        if (has_nav_menu('primary')) {
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'cad-nav-menu',
                'fallback_cb'    => false,
            ));
        } else {
            ?>
            <ul class="cad-nav-menu">
                <li class="cad-nav-item"><a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'autocad-consumer'); ?></a></li>
                <li class="cad-nav-item"><a href="<?php echo esc_url(class_exists('WooCommerce') ? wc_get_page_permalink('shop') : '#'); ?>"><?php esc_html_e('All CAD Products', 'autocad-consumer'); ?></a></li>
                <li class="cad-nav-item"><a href="<?php echo esc_url(home_url('/#cad-categories')); ?>"><?php esc_html_e('Categories', 'autocad-consumer'); ?></a></li>
                <li class="cad-nav-item"><a href="<?php echo esc_url(home_url('/#cad-services')); ?>"><?php esc_html_e('2D Drafting Services', 'autocad-consumer'); ?></a></li>
                <li class="cad-nav-item"><a href="<?php echo esc_url(home_url('/#cad-why')); ?>"><?php esc_html_e('Why Choose Us', 'autocad-consumer'); ?></a></li>
            </ul>
            <?php
        }
        ?>
        <a href="#cad-services" class="cad-nav-cta cad-open-quote-modal">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="12" y1="18" x2="12" y2="12"></line>
                <line x1="9" y1="15" x2="15" y2="15"></line>
            </svg>
            <?php esc_html_e('Request Custom Quote', 'autocad-consumer'); ?>
        </a>
    </div>
</nav>

<!-- Mobile Navigation Drawer Overlay -->
<div id="cadMobileOverlay" class="cad-drawer-backdrop"></div>
<aside id="cadMobileNav" class="cad-cart-drawer" style="right:auto; left:0; transform:translateX(-100%); border-left:none; border-right:2px solid var(--cad-technical-cyan);">
    <div class="cad-drawer-header">
        <h3 class="cad-drawer-title">
            <?php autocad_consumer_logo(); ?>
        </h3>
        <button type="button" class="cad-drawer-close" id="cadMobileNavClose" aria-label="<?php esc_attr_e('Close mobile menu', 'autocad-consumer'); ?>">✕</button>
    </div>
    <div class="cad-drawer-body">
        <form role="search" method="get" class="cad-search-form" action="<?php echo esc_url(home_url('/')); ?>" style="margin-bottom:20px;">
            <input type="search" class="cad-search-input" placeholder="<?php esc_attr_e('Search products...', 'autocad-consumer'); ?>" value="<?php echo get_search_query(); ?>" name="s" required />
            <input type="hidden" name="post_type" value="product" />
            <button type="submit" class="cad-search-submit">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
            </button>
        </form>
        <ul class="cad-mobile-nav-list" style="list-style:none; padding:0; margin:0 0 24px;">
            <li style="padding:10px 0; border-bottom:1px solid var(--cad-border-dark);"><a href="<?php echo esc_url(home_url('/')); ?>" style="color:#fff; font-weight:600;"><?php esc_html_e('Home', 'autocad-consumer'); ?></a></li>
            <li style="padding:10px 0; border-bottom:1px solid var(--cad-border-dark);"><a href="<?php echo esc_url(class_exists('WooCommerce') ? wc_get_page_permalink('shop') : '#'); ?>" style="color:#fff; font-weight:600;"><?php esc_html_e('All CAD Catalog', 'autocad-consumer'); ?></a></li>
            <li style="padding:10px 0; border-bottom:1px solid var(--cad-border-dark);"><a href="<?php echo esc_url(home_url('/#cad-categories')); ?>" style="color:#fff; font-weight:600;"><?php esc_html_e('CAD Categories', 'autocad-consumer'); ?></a></li>
            <li style="padding:10px 0; border-bottom:1px solid var(--cad-border-dark);"><a href="<?php echo esc_url(home_url('/#cad-services')); ?>" style="color:#fff; font-weight:600;"><?php esc_html_e('Drafting Services', 'autocad-consumer'); ?></a></li>
            <li style="padding:10px 0; border-bottom:1px solid var(--cad-border-dark);"><a href="<?php echo esc_url(class_exists('WooCommerce') ? wc_get_page_permalink('myaccount') : wp_login_url()); ?>" style="color:var(--cad-technical-cyan); font-weight:600;"><?php esc_html_e('My Account / Login', 'autocad-consumer'); ?></a></li>
        </ul>
        <div class="cad-header-socials" style="display:flex; justify-content:center; gap:12px;">
            <?php autocad_consumer_social_links(); ?>
        </div>
    </div>
</aside>

<!-- 6. Cart Side Drawer (Sliding from Right) -->
<div id="cadDrawerBackdrop" class="cad-drawer-backdrop"></div>
<aside id="cadCartDrawer" class="cad-cart-drawer" aria-label="<?php esc_attr_e('Shopping Cart Drawer', 'autocad-consumer'); ?>">
    <div class="cad-drawer-header">
        <h3 class="cad-drawer-title">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="9" cy="21" r="1"></circle>
                <circle cx="20" cy="21" r="1"></circle>
                <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
            </svg>
            <?php esc_html_e('Drafting Cart', 'autocad-consumer'); ?>
        </h3>
        <button type="button" id="cadDrawerClose" class="cad-drawer-close" aria-label="<?php esc_attr_e('Close Cart Drawer', 'autocad-consumer'); ?>">✕</button>
    </div>
    <?php autocad_consumer_render_drawer_body(); ?>
</aside>
<main id="primary" class="site-main">
