/**
 * AutoCad ConsumeR — Variable Product Variations Enhancer
 * Dynamically updates product image, price, SKU, and availability badge upon variation selection.
 */
(function($) {
  'use strict';

  $(document).ready(function() {
    var $variationsForm = $('.variations_form');

    if (!$variationsForm.length) return;

    $variationsForm.on('found_variation', function(event, variation) {
      if (!variation) return;

      // 1. Update Price
      if (variation.price_html) {
        $('.cad-single-price-wrap').html(variation.price_html);
      }

      // 2. Update Image
      if (variation.image && variation.image.src) {
        var $mainImg = $('.cad-main-prod-img');
        if ($mainImg.length) {
          $mainImg.attr('src', variation.image.src);
          if (variation.image.srcset) {
            $mainImg.attr('srcset', variation.image.srcset);
          }
        }
      }

      // 3. Update SKU
      var $skuWrap = $('.cad-prod-sku');
      if ($skuWrap.length) {
        $skuWrap.text(variation.sku || 'N/A');
      }

      // 4. Update Stock Availability
      var $stockWrap = $('.cad-prod-stock-status');
      if ($stockWrap.length) {
        if (variation.is_in_stock) {
          var stockText = variation.availability_html || '<span class="cad-in-stock" style="color:#10B981;">✓ In Stock</span>';
          $stockWrap.html(stockText);
          $('.single_add_to_cart_button').prop('disabled', false).removeClass('disabled');
        } else {
          $stockWrap.html('<span class="cad-out-of-stock" style="color:#E50914;">✕ Out of Stock</span>');
          $('.single_add_to_cart_button').prop('disabled', true).addClass('disabled');
        }
      }
    });

    $variationsForm.on('reset_data', function() {
      // Revert to initial product state
      var $initialPrice = $('.cad-initial-price');
      if ($initialPrice.length) {
        $('.cad-single-price-wrap').html($initialPrice.html());
      }
      var $initialImg = $('.cad-initial-img');
      if ($initialImg.length) {
        $('.cad-main-prod-img').attr('src', $initialImg.data('orig-src'));
      }
    });
  });

})(jQuery);
