<?php
/**
 * AutoCad ConsumeR — WooCommerce Setup and AJAX Cart Handlers
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Ensure BDT currency symbol is ৳
 */
add_filter('woocommerce_currency_symbol', 'autocad_consumer_currency_symbol', 10, 2);
function autocad_consumer_currency_symbol($currency_symbol, $currency) {
    if ($currency === 'BDT') {
        return '৳';
    }
    return $currency_symbol;
}

/**
 * AJAX Cart Drawer Fragments
 * Updates cart badge, total text, and drawer content seamlessly without page refresh.
 */
add_filter('woocommerce_add_to_cart_fragments', 'autocad_consumer_cart_drawer_fragments');
function autocad_consumer_cart_drawer_fragments($fragments) {
    if (!function_exists('WC') || !WC()->cart) {
        return $fragments;
    }

    $cart_count = WC()->cart->get_cart_contents_count();
    $cart_total = WC()->cart->get_cart_total();

    // 1. Badge Fragment
    $fragments['.cad-cart-badge'] = '<span class="cad-cart-badge">' . esc_html($cart_count) . '</span>';

    // 2. Total Text Fragment
    $fragments['.cad-cart-total-text'] = '<span class="cad-cart-total-text">' . wp_kses_post($cart_total) . '</span>';

    // 3. Full Drawer Body Fragment
    ob_start();
    autocad_consumer_render_drawer_body();
    $fragments['#cadCartDrawerContent'] = ob_get_clean();

    return $fragments;
}

/**
 * Render Cart Side Drawer HTML Body & Footer
 */
function autocad_consumer_render_drawer_body() {
    if (!function_exists('WC') || !WC()->cart) {
        return;
    }

    $cart = WC()->cart;
    $items = $cart->get_cart();
    ?>
    <div id="cadCartDrawerContent" style="display:flex; flex-direction:column; height:100%;">
        <div class="cad-drawer-body">
            <?php if (empty($items)) : ?>
                <div class="cad-drawer-empty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <circle cx="9" cy="21" r="1"/>
                        <circle cx="20" cy="21" r="1"/>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
                    </svg>
                    <p><?php esc_html_e('Your CAD drafting cart is empty.', 'autocad-consumer'); ?></p>
                    <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>" class="cad-btn cad-btn-secondary" style="font-size:0.875rem;">
                        <?php esc_html_e('Explore CAD Catalog', 'autocad-consumer'); ?>
                    </a>
                </div>
            <?php else : ?>
                <ul class="cad-drawer-items">
                    <?php
                    foreach ($items as $cart_item_key => $cart_item) :
                        $_product   = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                        $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);

                        if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_cart_item_visible', true, $cart_item, $cart_item_key)) :
                            $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
                            $thumbnail         = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(array(76, 76), array('class' => 'cad-drawer-item-img')), $cart_item, $cart_item_key);
                            $product_price     = apply_filters('woocommerce_cart_item_price', $cart->get_product_price($_product), $cart_item, $cart_item_key);
                            ?>
                            <li class="cad-drawer-item" data-cart-key="<?php echo esc_attr($cart_item_key); ?>">
                                <?php if (empty($product_permalink)) : ?>
                                    <?php echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput ?>
                                <?php else : ?>
                                    <a href="<?php echo esc_url($product_permalink); ?>">
                                        <?php echo $thumbnail; // phpcs:ignore WordPress.Security.EscapeOutput ?>
                                    </a>
                                <?php endif; ?>

                                <div class="cad-drawer-item-info">
                                    <span class="cad-drawer-item-title">
                                        <?php if (empty($product_permalink)) : ?>
                                            <?php echo wp_kses_post($_product->get_name()); ?>
                                        <?php else : ?>
                                            <a href="<?php echo esc_url($product_permalink); ?>">
                                                <?php echo wp_kses_post($_product->get_name()); ?>
                                            </a>
                                        <?php endif; ?>
                                    </span>

                                    <!-- Variation Metadata -->
                                    <?php if (!empty($cart_item['variation'])) : ?>
                                        <div class="cad-drawer-item-meta">
                                            <?php echo wc_get_formatted_cart_item_data($cart_item); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Line Price -->
                                    <div class="cad-drawer-item-price">
                                        <?php echo wp_kses_post($product_price); ?>
                                    </div>

                                    <!-- Quantity Controls (+ / -) -->
                                    <div class="cad-drawer-qty-wrap">
                                        <button type="button" class="cad-qty-btn cad-qty-minus" aria-label="<?php esc_attr_e('Decrease quantity', 'autocad-consumer'); ?>">-</button>
                                        <input type="number" class="cad-qty-input" value="<?php echo esc_attr($cart_item['quantity']); ?>" min="1" max="999" data-cart-key="<?php echo esc_attr($cart_item_key); ?>" readonly>
                                        <button type="button" class="cad-qty-btn cad-qty-plus" aria-label="<?php esc_attr_e('Increase quantity', 'autocad-consumer'); ?>">+</button>
                                    </div>

                                    <!-- Remove Button -->
                                    <button type="button" class="cad-drawer-remove" data-cart-key="<?php echo esc_attr($cart_item_key); ?>" aria-label="<?php esc_attr_e('Remove item', 'autocad-consumer'); ?>">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <line x1="18" y1="6" x2="6" y2="18"></line>
                                            <line x1="6" y1="6" x2="18" y2="18"></line>
                                        </svg>
                                    </button>
                                </div>
                            </li>
                            <?php
                        endif;
                    endforeach;
                    ?>
                </ul>
            <?php endif; ?>
        </div>

        <?php if (!empty($items)) : ?>
            <div class="cad-drawer-footer">
                <div class="cad-drawer-calc-row">
                    <span><?php esc_html_e('Subtotal:', 'autocad-consumer'); ?></span>
                    <span class="cad-drawer-subtotal-val"><?php echo wp_kses_post($cart->get_cart_subtotal()); ?></span>
                </div>

                <div class="cad-shipping-notice">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="16" x2="12" y2="12"></line>
                        <line x1="12" y1="8" x2="12.01" y2="8"></line>
                    </svg>
                    <span><?php esc_html_e('Digital downloads are delivered instantly after payment approval.', 'autocad-consumer'); ?></span>
                </div>

                <div class="cad-drawer-calc-row total-row">
                    <span><?php esc_html_e('Grand Total:', 'autocad-consumer'); ?></span>
                    <span class="cad-drawer-total-val"><?php echo wp_kses_post($cart->get_total()); ?></span>
                </div>

                <div class="cad-drawer-actions">
                    <a href="<?php echo esc_url(wc_get_checkout_url()); ?>" class="cad-btn-checkout">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                        <?php esc_html_e('Proceed to Checkout', 'autocad-consumer'); ?>
                    </a>
                    <a href="<?php echo esc_url(wc_get_cart_url()); ?>" class="cad-btn-viewcart">
                        <?php esc_html_e('View Cart Details', 'autocad-consumer'); ?>
                    </a>
                    <button type="button" class="cad-btn-continue">
                        <?php esc_html_e('Continue Shopping →', 'autocad-consumer'); ?>
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * AJAX: Update Cart Quantity in Slide-in Drawer
 */
add_action('wp_ajax_cad_update_cart_quantity', 'autocad_consumer_ajax_update_cart_qty');
add_action('wp_ajax_nopriv_cad_update_cart_quantity', 'autocad_consumer_ajax_update_cart_qty');
function autocad_consumer_ajax_update_cart_qty() {
    check_ajax_referer('cad_store_nonce', 'nonce');

    if (!function_exists('WC') || !WC()->cart) {
        wp_send_json_error(array('message' => 'Cart not available'));
    }

    $cart_key = isset($_POST['cart_key']) ? sanitize_text_field(wp_unslash($_POST['cart_key'])) : '';
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;

    if ($cart_key && $quantity > 0) {
        WC()->cart->set_quantity($cart_key, $quantity, true);
        WC()->cart->calculate_totals();

        $fragments = apply_filters('woocommerce_add_to_cart_fragments', array());
        wp_send_json_success(array('fragments' => $fragments));
    }

    wp_send_json_error(array('message' => 'Invalid parameters'));
}

/**
 * AJAX: Remove Cart Item from Slide-in Drawer
 */
add_action('wp_ajax_cad_remove_cart_item', 'autocad_consumer_ajax_remove_cart_item');
add_action('wp_ajax_nopriv_cad_remove_cart_item', 'autocad_consumer_ajax_remove_cart_item');
function autocad_consumer_ajax_remove_cart_item() {
    check_ajax_referer('cad_store_nonce', 'nonce');

    if (!function_exists('WC') || !WC()->cart) {
        wp_send_json_error(array('message' => 'Cart not available'));
    }

    $cart_key = isset($_POST['cart_key']) ? sanitize_text_field(wp_unslash($_POST['cart_key'])) : '';

    if ($cart_key) {
        WC()->cart->remove_cart_item($cart_key);
        WC()->cart->calculate_totals();

        $fragments = apply_filters('woocommerce_add_to_cart_fragments', array());
        wp_send_json_success(array('fragments' => $fragments));
    }

    wp_send_json_error(array('message' => 'Invalid cart key'));
}

/**
 * Digital-Only Cart Shipping Bypass:
 * Do not demand shipping details from a customer buying a digital or virtual item!
 */
add_filter('woocommerce_cart_needs_shipping_address', 'autocad_consumer_bypass_digital_shipping');
function autocad_consumer_bypass_digital_shipping($needs_address) {
    if (function_exists('WC') && WC()->cart) {
        if (!WC()->cart->needs_shipping()) {
            return false;
        }
    }
    return $needs_address;
}
