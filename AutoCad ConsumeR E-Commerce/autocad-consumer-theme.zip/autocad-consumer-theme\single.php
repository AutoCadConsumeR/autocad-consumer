<?php
/**
 * AutoCad ConsumeR — Single Post Template
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="cad-container" style="padding-top:40px; padding-bottom:60px; max-width:860px;">
    <?php
    while (have_posts()) :
        the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="cad-post-header" style="margin-bottom:24px;">
                <h1 class="cad-section-title" style="margin-bottom:12px;"><?php the_title(); ?></h1>
                <div style="font-size:0.875rem; color:var(--cad-text-muted);">
                    <span><?php esc_html_e('Published on', 'autocad-consumer'); ?> <?php echo get_the_date(); ?></span>
                    <span> &bull; </span>
                    <span><?php esc_html_e('By', 'autocad-consumer'); ?> <?php the_author(); ?></span>
                </div>
            </header>

            <?php if (has_post_thumbnail()) : ?>
                <div style="margin-bottom:28px; border-radius:var(--cad-radius-md); overflow:hidden;">
                    <?php the_post_thumbnail('large'); ?>
                </div>
            <?php endif; ?>

            <div class="cad-post-content" style="line-height:1.75; font-size:1.0625rem; color:var(--cad-text-main);">
                <?php the_content(); ?>
            </div>
        </article>
        <?php
    endwhile;
    ?>
</div>

<?php
get_footer();
