<?php
/**
 * AutoCad ConsumeR — 404 Not Found Template
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="cad-container" style="padding:100px 20px; text-align:center;">
    <div style="display:inline-block; margin-bottom:24px; padding:16px 24px; border:2px dashed var(--cad-brand-red); border-radius:var(--cad-radius-md); background:rgba(229,9,20,0.06);">
        <span style="font-family:var(--cad-font-mono); font-size:4rem; font-weight:800; color:var(--cad-brand-red); line-height:1;">404</span>
        <div style="font-family:var(--cad-font-mono); font-size:0.875rem; color:var(--cad-brand-red); text-transform:uppercase; letter-spacing:1px; margin-top:4px;">
            <?php esc_html_e('ERROR: CAD ENTITY NOT FOUND IN MODELSPACE', 'autocad-consumer'); ?>
        </div>
    </div>

    <h1 class="cad-section-title" style="margin-bottom:14px;"><?php esc_html_e('The Requested Drawing Coordinate Does Not Exist', 'autocad-consumer'); ?></h1>
    <p class="cad-section-subtitle" style="margin-bottom:32px;">
        <?php esc_html_e('The CAD file, template, or page you are looking for has been moved, purged, or renamed.', 'autocad-consumer'); ?>
    </p>

    <div style="max-width:480px; margin:0 auto 36px;">
        <form role="search" method="get" class="cad-search-form" action="<?php echo esc_url(home_url('/')); ?>">
            <input type="search" class="cad-search-input" placeholder="<?php esc_attr_e('Search CAD catalog...', 'autocad-consumer'); ?>" value="" name="s" required />
            <input type="hidden" name="post_type" value="product" />
            <button type="submit" class="cad-search-submit">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
            </button>
        </form>
    </div>

    <a href="<?php echo esc_url(home_url('/')); ?>" class="cad-btn cad-btn-primary">
        <?php esc_html_e('Return to Workspace Home', 'autocad-consumer'); ?>
    </a>
</div>

<?php
get_footer();
