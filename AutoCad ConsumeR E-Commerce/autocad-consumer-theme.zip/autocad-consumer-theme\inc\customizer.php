<?php
/**
 * AutoCad ConsumeR — Theme Customizer Options
 * Allows site owner to configure branding, contact info, social links, and homepage hero without touching code.
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

function autocad_consumer_customize_register($wp_customize) {
    // 1. BRANDING & ACCENT COLORS PANEL
    $wp_customize->add_section('autocad_branding_section', array(
        'title'       => __('AutoCad ConsumeR Branding', 'autocad-consumer'),
        'priority'    => 25,
        'description' => __('Customize brand colors and header presentation.', 'autocad-consumer'),
    ));

    $wp_customize->add_setting('cad_accent_color', array(
        'default'           => '#E50914',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'cad_accent_color', array(
        'label'    => __('Brand Accent Color (Red/Crimson)', 'autocad-consumer'),
        'section'  => 'autocad_branding_section',
        'settings' => 'cad_accent_color',
    )));

    $wp_customize->add_setting('cad_tech_color', array(
        'default'           => '#25C7D9',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'cad_tech_color', array(
        'label'    => __('Technical Accent Color (Cyan)', 'autocad-consumer'),
        'section'  => 'autocad_branding_section',
        'settings' => 'cad_tech_color',
    )));

    // 2. CONTACT INFORMATION
    $wp_customize->add_section('autocad_contact_section', array(
        'title'    => __('Business Contact Info', 'autocad-consumer'),
        'priority' => 30,
    ));

    $wp_customize->add_setting('cad_phone', array(
        'default'           => '+880 1712-345678',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cad_phone', array(
        'label'   => __('Phone / Hotline', 'autocad-consumer'),
        'section' => 'autocad_contact_section',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('cad_whatsapp', array(
        'default'           => '+880 1712-345678',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cad_whatsapp', array(
        'label'   => __('WhatsApp Support Number', 'autocad-consumer'),
        'section' => 'autocad_contact_section',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('cad_email', array(
        'default'           => 'support@autocadconsumer.com',
        'sanitize_callback' => 'sanitize_email',
    ));
    $wp_customize->add_control('cad_email', array(
        'label'   => __('Business Email', 'autocad-consumer'),
        'section' => 'autocad_contact_section',
        'type'    => 'email',
    ));

    $wp_customize->add_setting('cad_address', array(
        'default'           => 'Engineering Tower, Level 4, Panthapath, Dhaka-1205, Bangladesh',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cad_address', array(
        'label'   => __('Business Address', 'autocad-consumer'),
        'section' => 'autocad_contact_section',
        'type'    => 'textarea',
    ));

    // 3. SOCIAL MEDIA LINKS (ADMIN-EDITABLE WITH SHOW/HIDE)
    $wp_customize->add_section('autocad_social_section', array(
        'title'       => __('Social Media Links (Header & Footer)', 'autocad-consumer'),
        'priority'    => 35,
        'description' => __('Configure social links. Leave URL empty or uncheck to hide.', 'autocad-consumer'),
    ));

    $social_networks = array(
        'facebook'  => __('Facebook', 'autocad-consumer'),
        'instagram' => __('Instagram', 'autocad-consumer'),
        'youtube'   => __('YouTube', 'autocad-consumer'),
        'tiktok'    => __('TikTok', 'autocad-consumer'),
        'whatsapp'  => __('WhatsApp', 'autocad-consumer'),
        'linkedin'  => __('LinkedIn', 'autocad-consumer'),
    );

    foreach ($social_networks as $key => $label) {
        $wp_customize->add_setting('cad_show_' . $key, array(
            'default'           => true,
            'sanitize_callback' => 'wp_validate_boolean',
        ));
        $wp_customize->add_control('cad_show_' . $key, array(
            'label'   => sprintf(__('Show %s Icon', 'autocad-consumer'), $label),
            'section' => 'autocad_social_section',
            'type'    => 'checkbox',
        ));

        $wp_customize->add_setting('cad_url_' . $key, array(
            'default'           => 'https://' . $key . '.com/autocadconsumer',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control('cad_url_' . $key, array(
            'label'   => sprintf(__('%s URL', 'autocad-consumer'), $label),
            'section' => 'autocad_social_section',
            'type'    => 'url',
        ));
    }

    // 4. HOMEPAGE HERO SETTINGS
    $wp_customize->add_section('autocad_hero_section', array(
        'title'    => __('Homepage Hero Banner', 'autocad-consumer'),
        'priority' => 40,
    ));

    $wp_customize->add_setting('cad_hero_tag', array(
        'default'           => 'PRECISION ENGINEERING & CAD SOLUTIONS',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cad_hero_tag', array(
        'label'   => __('Hero Subtitle / Tag', 'autocad-consumer'),
        'section' => 'autocad_hero_section',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('cad_hero_title', array(
        'default'           => 'Supercharge Your Drafting Workflow with AutoCad ConsumeR',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cad_hero_title', array(
        'label'   => __('Hero Headline', 'autocad-consumer'),
        'section' => 'autocad_hero_section',
        'type'    => 'text',
    ));

    $wp_customize->add_setting('cad_hero_desc', array(
        'default'           => 'Premium AutoCAD templates, dynamic blocks, structural drafting libraries, and professional 2D conversion services tailored for architects, engineers, and CAD professionals.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cad_hero_desc', array(
        'label'   => __('Hero Description', 'autocad-consumer'),
        'section' => 'autocad_hero_section',
        'type'    => 'textarea',
    ));
}
add_action('customize_register', 'autocad_consumer_customize_register');
