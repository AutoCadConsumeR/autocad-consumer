/**
 * AutoCad ConsumeR — Main Frontend Scripts
 * Handles mobile navigation, category filtering, quote modal, and interactive CAD features.
 */
(function($) {
  'use strict';

  var AutoCadApp = {
    init: function() {
      this.initMobileNav();
      this.initCategoryFilters();
      this.initQuoteModal();
      this.initSmoothScroll();
    },

    // Mobile Navigation Drawer
    initMobileNav: function() {
      var $toggle = $('#cadMobileToggle');
      var $menu = $('#cadMobileNav');
      var $overlay = $('#cadMobileOverlay');

      $toggle.on('click', function(e) {
        e.preventDefault();
        $menu.toggleClass('active');
        $overlay.toggleClass('active');
        $('body').toggleClass('cad-mobile-open');
      });

      $overlay.on('click', function() {
        $menu.removeClass('active');
        $overlay.removeClass('active');
        $('body').removeClass('cad-mobile-open');
      });
    },

    // Latest Products Category Filtering
    initCategoryFilters: function() {
      var $tabs = $('.cad-filter-tab');
      var $cards = $('.cad-prod-card');

      $tabs.on('click', function(e) {
        e.preventDefault();
        var $tab = $(this);
        var targetCat = $tab.data('cat-slug');

        $tabs.removeClass('active');
        $tab.addClass('active');

        if (targetCat === 'all' || !targetCat) {
          $cards.fadeIn(250);
        } else {
          $cards.each(function() {
            var cardCats = $(this).data('cats') || '';
            if (cardCats.indexOf(targetCat) !== -1) {
              $(this).fadeIn(250);
            } else {
              $(this).fadeOut(150);
            }
          });
        }
      });
    },

    // Quote Request Modal
    initQuoteModal: function() {
      var $modal = $('#cadQuoteModal');
      var $triggers = $('.cad-open-quote-modal');
      var $close = $('#cadQuoteModalClose, #cadQuoteModalCancel');

      $triggers.on('click', function(e) {
        e.preventDefault();
        var serviceName = $(this).data('service-title') || 'Custom CAD Drafting Service';
        $modal.find('#cadQuoteService').val(serviceName);
        $modal.addClass('active');
        $('body').addClass('cad-modal-open');
      });

      $close.on('click', function(e) {
        e.preventDefault();
        $modal.removeClass('active');
        $('body').removeClass('cad-modal-open');
      });

      $(document).on('keydown', function(e) {
        if (e.key === 'Escape' && $modal.hasClass('active')) {
          $modal.removeClass('active');
          $('body').removeClass('cad-modal-open');
        }
      });

      // Handle Quote Form AJAX Submission
      $('#cadQuoteForm').on('submit', function(e) {
        e.preventDefault();
        var $form = $(this);
        var $submitBtn = $form.find('button[type="submit"]');
        var $msgBox = $form.find('.cad-quote-response-msg');

        // Check honeypot
        if ($form.find('input[name="cad_website_hp"]').val()) {
          return false; // Silent rejection for bots
        }

        var formData = new FormData(this);
        formData.append('action', 'cad_submit_quote_request');
        formData.append('nonce', (window.cadStoreData && window.cadStoreData.quoteNonce) ? window.cadStoreData.quoteNonce : '');

        $submitBtn.prop('disabled', true).text('Transmitting Request...');
        $msgBox.hide().empty();

        $.ajax({
          type: 'POST',
          url: (window.cadStoreData && window.cadStoreData.ajaxUrl) ? window.cadStoreData.ajaxUrl : '/wp-admin/admin-ajax.php',
          data: formData,
          processData: false,
          contentType: false,
          success: function(res) {
            $submitBtn.prop('disabled', false).text('Submit Quote Request');
            if (res && res.success) {
              $msgBox.html('<div class="cad-alert-success" style="color:#10B981; padding:12px; border:1px solid #10B981; border-radius:6px; margin-top:12px;">' + (res.data.message || 'Quote request received! Our engineering team will contact you shortly.') + '</div>').fadeIn();
              $form[0].reset();
            } else {
              var err = (res && res.data && res.data.message) ? res.data.message : 'Error transmitting quote. Please check your inputs.';
              $msgBox.html('<div class="cad-alert-error" style="color:#E50914; padding:12px; border:1px solid #E50914; border-radius:6px; margin-top:12px;">' + err + '</div>').fadeIn();
            }
          },
          error: function() {
            $submitBtn.prop('disabled', false).text('Submit Quote Request');
            $msgBox.html('<div class="cad-alert-error" style="color:#E50914; padding:12px; border:1px solid #E50914; border-radius:6px; margin-top:12px;">Connection error. Please try again or reach us via WhatsApp.</div>').fadeIn();
          }
        });
      });
    },

    // Smooth Scroll
    initSmoothScroll: function() {
      $('a[href^="#"]:not([href="#"])').on('click', function(e) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
          e.preventDefault();
          $('html, body').stop().animate({
            scrollTop: target.offset().top - 90
          }, 600);
        }
      });
    }
  };

  $(document).ready(function() {
    AutoCadApp.init();
  });

})(jQuery);
