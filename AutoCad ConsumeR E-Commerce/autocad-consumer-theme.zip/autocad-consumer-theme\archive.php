<?php
/**
 * AutoCad ConsumeR — Archive Template
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="cad-container" style="padding-top:40px; padding-bottom:60px;">
    <header class="cad-section-header" style="text-align:left; margin-bottom:36px; border-bottom:1px solid var(--cad-border-light); padding-bottom:16px;">
        <span class="cad-section-tag"><?php esc_html_e('ARCHIVE', 'autocad-consumer'); ?></span>
        <h1 class="cad-section-title" style="margin-top:8px;"><?php the_archive_title(); ?></h1>
        <?php if (get_the_archive_description()) : ?>
            <div class="cad-section-subtitle" style="margin-left:0;"><?php the_archive_description(); ?></div>
        <?php endif; ?>
    </header>

    <?php if (have_posts()) : ?>
        <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:24px;">
            <?php
            while (have_posts()) :
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('cad-prod-card'); ?> style="padding:20px;">
                    <h2 style="font-size:1.15rem; margin-bottom:8px;">
                        <a href="<?php the_permalink(); ?>" style="color:var(--cad-text-main);"><?php the_title(); ?></a>
                    </h2>
                    <div style="font-size:0.8rem; color:var(--cad-text-muted); margin-bottom:12px;">
                        <?php echo get_the_date(); ?>
                    </div>
                    <div style="font-size:0.875rem; color:var(--cad-text-muted); margin-bottom:16px; line-height:1.5;">
                        <?php the_excerpt(); ?>
                    </div>
                    <a href="<?php the_permalink(); ?>" class="cad-btn cad-btn-secondary" style="font-size:0.8125rem; padding:8px 14px; align-self:flex-start;">
                        <?php esc_html_e('Read More →', 'autocad-consumer'); ?>
                    </a>
                </article>
                <?php
            endwhile;
            ?>
        </div>
        <div style="margin-top:36px;">
            <?php the_posts_pagination(); ?>
        </div>
    <?php else : ?>
        <p><?php esc_html_e('No items found in this archive.', 'autocad-consumer'); ?></p>
    <?php endif; ?>
</div>

<?php
get_footer();
