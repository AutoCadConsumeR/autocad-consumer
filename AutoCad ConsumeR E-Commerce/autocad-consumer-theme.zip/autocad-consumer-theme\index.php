<?php
/**
 * AutoCad ConsumeR — Index Template
 *
 * @package AutoCad_ConsumeR
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<div class="cad-container" style="padding-top:40px; padding-bottom:60px;">
    <?php if (have_posts()) : ?>
        <header class="cad-section-header" style="text-align:left; margin-bottom:32px;">
            <h1 class="cad-section-title"><?php esc_html_e('CAD Blog & Industry Insights', 'autocad-consumer'); ?></h1>
        </header>

        <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(320px, 1fr)); gap:28px;">
            <?php
            while (have_posts()) :
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('cad-prod-card'); ?> style="padding:24px;">
                    <h2 style="font-size:1.25rem; margin-bottom:10px;">
                        <a href="<?php the_permalink(); ?>" style="color:var(--cad-text-main);"><?php the_title(); ?></a>
                    </h2>
                    <div style="font-size:0.8125rem; color:var(--cad-text-muted); margin-bottom:14px;">
                        <?php echo get_the_date(); ?>
                    </div>
                    <div style="font-size:0.875rem; color:var(--cad-text-muted); line-height:1.6; margin-bottom:16px;">
                        <?php the_excerpt(); ?>
                    </div>
                    <a href="<?php the_permalink(); ?>" class="cad-btn cad-btn-secondary" style="font-size:0.8125rem; padding:8px 14px; align-self:flex-start;">
                        <?php esc_html_e('Read Full Article →', 'autocad-consumer'); ?>
                    </a>
                </article>
                <?php
            endwhile;
            ?>
        </div>

        <div style="margin-top:40px;">
            <?php the_posts_pagination(); ?>
        </div>
    <?php else : ?>
        <p><?php esc_html_e('No articles found.', 'autocad-consumer'); ?></p>
    <?php endif; ?>
</div>

<?php
get_footer();
