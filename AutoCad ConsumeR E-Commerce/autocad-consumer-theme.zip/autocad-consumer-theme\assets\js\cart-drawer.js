/**
 * AutoCad ConsumeR — Slide-in Cart Drawer Controller
 * Handles open/close, AJAX quantity change, AJAX item removal, and auto-open on add-to-cart.
 */
(function($) {
  'use strict';

  var CartDrawer = {
    init: function() {
      this.cacheDom();
      this.bindEvents();
    },

    cacheDom: function() {
      this.$drawer = $('#cadCartDrawer');
      this.$backdrop = $('#cadDrawerBackdrop');
      this.$trigger = $('.cad-cart-trigger');
      this.$closeBtn = $('#cadDrawerClose, .cad-btn-continue');
      this.$body = $('body');
    },

    bindEvents: function() {
      var self = this;

      // Open drawer on cart trigger click
      $(document).on('click', '.cad-cart-trigger', function(e) {
        e.preventDefault();
        self.open();
      });

      // Close drawer on close button or backdrop click
      $(document).on('click', '#cadDrawerClose, .cad-btn-continue, #cadDrawerBackdrop', function(e) {
        e.preventDefault();
        self.close();
      });

      // Close on Escape key
      $(document).on('keydown', function(e) {
        if (e.key === 'Escape' && self.$drawer.hasClass('active')) {
          self.close();
        }
      });

      // Auto open drawer when an item is added to cart
      $(document.body).on('added_to_cart', function(event, fragments, cart_hash, $button) {
        self.open();
        self.updateDrawerFragments(fragments);
      });

      // Update quantity (+ / -) in cart drawer via AJAX
      $(document).on('click', '.cad-drawer-qty-wrap .cad-qty-btn', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $input = $btn.siblings('.cad-qty-input');
        var cartKey = $input.data('cart-key');
        var currentQty = parseInt($input.val(), 10) || 1;
        var newQty = currentQty;

        if ($btn.hasClass('cad-qty-plus')) {
          newQty = currentQty + 1;
        } else if ($btn.hasClass('cad-qty-minus')) {
          newQty = Math.max(1, currentQty - 1);
        }

        if (newQty !== currentQty) {
          $input.val(newQty);
          self.updateCartQty(cartKey, newQty);
        }
      });

      // Remove item from cart drawer via AJAX
      $(document).on('click', '.cad-drawer-remove', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var cartKey = $btn.data('cart-key');
        self.removeItem(cartKey);
      });
    },

    open: function() {
      this.$drawer.addClass('active');
      this.$backdrop.addClass('active');
      this.$body.addClass('cad-drawer-open');
    },

    close: function() {
      this.$drawer.removeClass('active');
      this.$backdrop.removeClass('active');
      this.$body.removeClass('cad-drawer-open');
    },

    updateDrawerFragments: function(fragments) {
      if (fragments) {
        $.each(fragments, function(key, value) {
          $(key).replaceWith(value);
        });
      }
    },

    updateCartQty: function(cartKey, quantity) {
      var self = this;
      self.$drawer.find('.cad-drawer-body').css('opacity', '0.5');

      $.ajax({
        type: 'POST',
        url: (window.cadStoreData && window.cadStoreData.ajaxUrl) ? window.cadStoreData.ajaxUrl : '/wp-admin/admin-ajax.php',
        data: {
          action: 'cad_update_cart_quantity',
          cart_key: cartKey,
          quantity: quantity,
          nonce: (window.cadStoreData && window.cadStoreData.nonce) ? window.cadStoreData.nonce : ''
        },
        success: function(response) {
          self.$drawer.find('.cad-drawer-body').css('opacity', '1');
          if (response && response.fragments) {
            self.updateDrawerFragments(response.fragments);
          } else {
            $(document.body).trigger('wc_fragment_refresh');
          }
        },
        error: function() {
          self.$drawer.find('.cad-drawer-body').css('opacity', '1');
        }
      });
    },

    removeItem: function(cartKey) {
      var self = this;
      self.$drawer.find('.cad-drawer-body').css('opacity', '0.5');

      $.ajax({
        type: 'POST',
        url: (window.cadStoreData && window.cadStoreData.ajaxUrl) ? window.cadStoreData.ajaxUrl : '/wp-admin/admin-ajax.php',
        data: {
          action: 'cad_remove_cart_item',
          cart_key: cartKey,
          nonce: (window.cadStoreData && window.cadStoreData.nonce) ? window.cadStoreData.nonce : ''
        },
        success: function(response) {
          self.$drawer.find('.cad-drawer-body').css('opacity', '1');
          if (response && response.fragments) {
            self.updateDrawerFragments(response.fragments);
          } else {
            $(document.body).trigger('wc_fragment_refresh');
          }
        },
        error: function() {
          self.$drawer.find('.cad-drawer-body').css('opacity', '1');
        }
      });
    }
  };

  $(document).ready(function() {
    CartDrawer.init();
  });

})(jQuery);
